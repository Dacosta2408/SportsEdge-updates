/* Sports Edge - NFL Top 5 player cards 1.0
   Shows the top 5 players under the header on Quarterbacks, Receivers, Rushing, Injuries, Defense and Special Teams.
   Also keeps the page header and this card on screen when "Week by week" is selected.
   Needs /static/playercard_nfl.jpg. Off switch: localStorage.pc5_off=1 then reload. */
(function(){
try{if(localStorage.getItem("pc5_off")==="1")return}catch(e){}
if(window.__pc5)return;window.__pc5=1;
const E=s=>String(s==null?"":s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const num=x=>{x=Number(x);return isFinite(x)?x:0};
const fm=x=>{if(x==null||x==="")return"-";x=Number(x);if(!isFinite(x))return"-";return Number.isInteger(x)?String(x):String(Math.round(x*10)/10)};
const HURT=/out|doubt|quest|day|reserve|\bir\b|susp/i;
const ESPN=id=>"https://a.espncdn.com/i/headshots/nfl/players/full/"+id+".png";
const PORT=id=>"/api/edge_auto/portrait/nfl_player_"+id+".png";
const LG=a=>(typeof logo==="function"&&a)?logo(a):"";
const TITLE={qb:"Quarterbacks",receivers:"Receivers",rushing:"Rushing",inj:"Injuries",def:"Defense",st:"Special Teams"};
const BASIS={qb:"by HitScore",receivers:"by HitScore",rushing:"by HitScore",inj:"most important players on the injury report",def:"by total tackles"};
const STT={kickers:{t:"Kickers",key:"kickers",sort:"pts",cols:[["PTS","pts"],["FG%","fgpct"],["LNG","long"]]},
 punters:{t:"Punters",key:"punters",sort:"yds",cols:[["PUNTS","no"],["AVG","avg"],["IN20","in20"]]},
 kr:{t:"Kick returns",key:"kick_returners",sort:"yds",cols:[["RET","no"],["YDS","yds"],["AVG","avg"]]},
 pr:{t:"Punt returns",key:"punt_returners",sort:"yds",cols:[["RET","no"],["YDS","yds"],["AVG","avg"]]}};

(function(){if(document.getElementById("pc5-css"))return;const s=document.createElement("style");s.id="pc5-css";
s.textContent=`.pc5{margin:12px 0 16px}
.pc5-head{display:flex;align-items:baseline;gap:10px;margin:0 0 8px;flex-wrap:wrap}.pc5-head b{font-size:15px}.pc5-head span{font-size:12px;color:#8a94a6}
.pc5-row{display:grid;grid-template-columns:repeat(5,minmax(132px,200px));gap:12px;overflow-x:auto;padding:2px 2px 6px}
.pc5-card{position:relative;aspect-ratio:848/1264;border-radius:10px;overflow:hidden;background:url(/static/playercard_nfl.jpg) center/100% 100% no-repeat,linear-gradient(160deg,#0b3550,#061a2e);color:#e8fbff;transition:transform .12s,box-shadow .12s}
.pc5-card:hover{transform:translateY(-3px);box-shadow:0 8px 20px rgba(0,190,255,.35)}
.pc5-face{position:absolute;left:12.6%;right:12.2%;top:10.2%;bottom:20.7%;overflow:hidden}
.pc5-face img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:50% 12%;filter:drop-shadow(0 4px 8px rgba(0,0,0,.55))}
.pc5-face::after{content:"";position:absolute;left:0;right:0;bottom:0;height:22%;background:linear-gradient(180deg,transparent,rgba(2,16,32,.75))}
.pc5-rank{position:absolute;left:14%;top:11%;font-weight:900;font-size:12px;color:#7cecff;text-shadow:0 0 6px rgba(0,200,255,.9);z-index:2}
.pc5-info{position:absolute;left:12.6%;right:12.2%;top:80.9%;height:11.4%;display:flex;flex-direction:column;justify-content:center;gap:2px;padding:0 6px;background:rgba(2,16,32,.88);overflow:hidden;box-sizing:border-box;z-index:2}
.pc5-n{display:flex;align-items:center;justify-content:space-between;gap:4px;min-width:0}
.pc5-n b{font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:#fff}
.pc5-n span{font-size:9px;color:#8fdcf0;white-space:nowrap;display:flex;align-items:center;gap:3px;flex:none}
.pc5-n img.logo{width:12px;height:12px}
.pc5-s{display:flex;justify-content:space-between;gap:4px;font-size:10px;font-weight:800;color:#7cecff;white-space:nowrap}
.pc5-s i{font-style:normal;font-size:7.5px;font-weight:700;color:#7aa6b8;margin-right:2px}
.pc5-bad .pc5-rank{color:#ffb454;text-shadow:0 0 6px rgba(255,160,40,.9)}`;
document.head.appendChild(s)})();

window.pc5Err=function(im){const f=im.dataset.f;if(f&&!im.dataset.t){im.dataset.t="1";im.src=f}else im.style.visibility="hidden"};

function kind(v){
 try{if(/^sp:/.test(String(page)))return null}catch(e){}
 const h=v.querySelector("h1,h2,h3");if(!h)return null;
 const t=h.textContent.trim().toLowerCase();
 if(t.startsWith("quarterbacks"))return"qb";
 if(t.startsWith("receivers"))return"receivers";
 if(t.startsWith("rushing"))return"rushing";
 if(/^(players?\s*[-:]?\s*)?injur/.test(t))return"inj";
 if(t.startsWith("defense"))return"def";
 if(t.startsWith("special teams"))return"st";
 return null}

function topGroup(g){
 const L=(typeof ALL!=="undefined"&&ALL[g])||[];
 return L.filter(r=>r&&r.id!=null).slice().sort((a,b)=>num(b.score)-num(a.score)).slice(0,5)
  .map(r=>({id:r.id,name:r.name,team:r.team,pos:r.pos||"",g,s:[["AVG",fm(r.avg)],["L3",fm(r.last3)],["HS",fm(r.score)]]}))}
function shortStatus(s){s=String(s||"");return /reserve|\bir\b/i.test(s)?"IR":/out/i.test(s)?"OUT":/doubt/i.test(s)?"DOUBT":/quest/i.test(s)?"QUEST":/day/i.test(s)?"DTD":/susp/i.test(s)?"SUSP":s.slice(0,6).toUpperCase()}
function topInj(){
 if(typeof ALL==="undefined")return[];
 const seen=new Set(),pool=[];
 ["qb","receivers","rushing"].forEach(g=>{const L=ALL[g]||[],mx=Math.max(1,...L.map(r=>num(r.avg)));
  L.forEach(r=>{if(!r||r.id==null||seen.has(r.id)||!r.injury||!HURT.test(r.injury))return;seen.add(r.id);pool.push({r,g,w:num(r.avg)/mx})})});
 return pool.sort((a,b)=>b.w-a.w).slice(0,5).map(o=>({id:o.r.id,name:o.r.name,team:o.r.team,pos:o.r.pos||"",g:o.g,bad:1,s:[["STATUS",shortStatus(o.r.injury)],["AVG",fm(o.r.avg)],["POS",o.r.pos||"-"]]}))}

let DEFD=null,DEFT=0,DEFB=false;
function loadDef(){
 if(DEFB||Date.now()-DEFT<300000)return;DEFB=true;
 fetch("/api/defense/players").then(r=>{if(!r.ok)throw 0;return r.json()}).then(d=>{DEFD=d}).catch(()=>{}).finally(()=>{DEFT=Date.now();DEFB=false;run()})}
function topDef(){
 return((DEFD&&DEFD.defense)||[]).slice().sort((a,b)=>num(b.tot)-num(a.tot)||num(b.sacks)-num(a.sacks)).slice(0,5)
  .map(r=>({id:r.id,name:r.name,team:r.team,pos:r.pos||r.grp||"",s:[["TKL",fm(r.tot)],["SACK",fm(r.sacks)],["INT",fm(r.ints)]]}))}
function stTab(v){
 const on=[...v.querySelectorAll(".dfx-tabs button.on")].map(x=>x.textContent.trim().toLowerCase());
 for(const t of on){if(t==="kickers")return"kickers";if(t==="punters")return"punters";if(t==="kick returns")return"kr";if(t==="punt returns")return"pr"}return"kickers"}
function topSt(tab){
 const c=STT[tab];
 return((DEFD&&DEFD[c.key])||[]).slice().sort((a,b)=>num(b[c.sort])-num(a[c.sort])).slice(0,5)
  .map(r=>({id:r.id,name:r.name,team:r.team,pos:r.pos||"",s:c.cols.map(x=>[x[0],fm(r[x[1]])])}))}

function cardHtml(it,i){
 const click=(it.g&&typeof pl==="function")?` onclick="pl('${E(it.id)}','${it.g}')" style="cursor:pointer"`:"";
 const img=it.id!=null?`<img alt="" loading="lazy" src="${E(ESPN(it.id))}" data-f="${E(PORT(it.id))}" onerror="pc5Err(this)">`:"";
 return `<div class="pc5-card${it.bad?" pc5-bad":""}"${click}><div class="pc5-face">${img}</div><span class="pc5-rank">#${i+1}</span>
 <div class="pc5-info"><div class="pc5-n"><b>${E(it.name)}</b><span>${LG(it.team)}${E(it.team||"")}${it.pos?" &middot; "+E(it.pos):""}</span></div>
 <div class="pc5-s">${it.s.map(x=>`<span><i>${E(x[0])}</i>${E(x[1])}</span>`).join("")}</div></div></div>`}
function html(items,k,tab){
 const title=k==="st"?"Special Teams - "+STT[tab].t:TITLE[k];
 const basis=k==="st"?"by "+STT[tab].sort:BASIS[k];
 return `<div class="pc5-head"><b>Top 5 - ${E(title)}</b><span>${E(basis)} | updates automatically</span></div><div class="pc5-row">${items.map(cardHtml).join("")}</div>`}

function anchorFor(v,k){
 const h=v.querySelector("h1,h2,h3");if(!h)return null;
 let top=h;while(top.parentElement&&top.parentElement!==v)top=top.parentElement;
 const trd=k==="qb"||k==="receivers"||k==="rushing";
 if(trd){let p=top.previousElementSibling;while(p){if(p.id!=="pc5"){p.classList.add("trd-keep");if(p.style.display==="none")p.style.display=""}p=p.previousElementSibling}}
 let a=top,n=a.nextElementSibling,c=0;
 const isData=el=>el.matches("table,.tw,.trd-body,.trd-wrap,.dfx-card,.pkc")||!!el.querySelector("table");
 if(trd){
  while(n&&c<4){
   if(n.id==="pc5"){n=n.nextElementSibling;continue}
   if(n.classList.contains("trd-bar")){a=n;n=n.nextElementSibling;c++;continue}
   if(isData(n)||n.classList.contains("trd-body"))break;
   n.classList.add("trd-keep");if(n.style.display==="none")n.style.display="";a=n;n=n.nextElementSibling;c++}
 }else if(k==="def"||k==="st"){
  if(n&&n.id==="pc5")n=n.nextElementSibling;
  if(n&&n.classList.contains("dfx-tabs"))a=n}
 return a}

function run(){
 const v=document.getElementById("view");if(!v)return;
 const old=v.querySelector("#pc5"),k=kind(v);
 if(!k){if(old)old.remove();return}
 if(typeof ALL==="undefined"||!ALL.qb)return;
 let items=null,tab="";
 if(k==="qb"||k==="receivers"||k==="rushing")items=topGroup(k);
 else if(k==="inj")items=topInj();
 else{loadDef();if(DEFD){if(k==="def")items=topDef();else{tab=stTab(v);items=topSt(tab)}}}
 if(!items)return;
 if(!items.length){if(old)old.remove();return}
 const a=anchorFor(v,k);if(!a)return;
 const sig=k+"|"+tab+"|"+JSON.stringify(items.map(i=>[i.id,i.name,i.s]));
 let el=old;
 if(!el||el.dataset.sig!==sig){
  const n=document.createElement("section");n.id="pc5";n.className="pc5 trd-keep";n.dataset.sig=sig;n.innerHTML=html(items,k,tab);
  if(el)el.replaceWith(n);el=n}
 if(el.previousElementSibling!==a)a.insertAdjacentElement("afterend",el)}

async function refresh(){
 if(document.hidden)return;
 try{const gs=["qb","receivers","rushing"],p=await Promise.all(gs.map(g=>fetch("/api/group/"+g).then(r=>r.json())));
  if(p.every(Array.isArray))gs.forEach((g,i)=>{ALL[g]=p[i]})}catch(e){}
 DEFT=0;run()}

let t1=null;const v0=document.getElementById("view");
if(v0)new MutationObserver(()=>{clearTimeout(t1);t1=setTimeout(()=>{try{run()}catch(e){console.log("pc5",e)}},120)}).observe(v0,{childList:true,subtree:true});
setInterval(()=>{try{run()}catch(e){}},3000);
setInterval(refresh,300000);
})();
