/* Sports Edge - NBA Top player cards 1.0
   A row of top players under the header on NBA Scoring, Rebounds, Assists, Threes, Steals, Blocks, Injuries and Defense.
   5 to 8 cards fill the row. Click a card for a player pop-up with season stats, last 10 games and the game log.
   Needs /static/playercard_nba.jpg. Off switch: localStorage.pcn_off=1 */
(function(){
try{if(localStorage.getItem("pcn_off")==="1")return}catch(e){}
if(window.__pcn)return;window.__pcn=1;
const E=s=>String(s==null?"":s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const num=x=>{x=Number(x);return isFinite(x)?x:0};
const fm=x=>{if(x==null||x==="")return"-";x=Number(x);if(!isFinite(x))return"-";return Number.isInteger(x)?String(x):String(Math.round(x*10)/10)};
const PAGES={scoring:["pts","Scoring","PTS"],rebounds:["reb","Rebounds","REB"],assists:["ast","Assists","AST"],threes:["fg3","Threes","3PM"],steals:["stl","Steals","STL"],blocks:["blk","Blocks","BLK"]};
const STATS=["pts","reb","ast","fg3","stl","blk"];
const LAB={pts:"PTS",reb:"REB",ast:"AST",fg3:"3PM",stl:"STL",blk:"BLK"};
const IMG=id=>"https://a.espncdn.com/combiner/i?img=/i/headshots/nba/players/full/"+id+".png&w=350&h=254";
const ESPN=id=>"https://a.espncdn.com/i/headshots/nba/players/full/"+id+".png";

const st=document.createElement("style");st.id="pcn-css";
st.textContent=`.pcn{margin:12px 0 16px}
.pcn-head{display:flex;align-items:baseline;gap:10px;margin:0 0 8px;flex-wrap:wrap}.pcn-head b{font-size:15px}.pcn-head span{font-size:12px;color:#8a94a6}
.pcn-row{display:grid;grid-template-columns:repeat(var(--n,5),minmax(0,1fr));gap:12px;padding:2px 2px 6px}
.pcn-card{position:relative;aspect-ratio:848/1264;border-radius:10px;overflow:hidden;cursor:pointer;background:url(/static/playercard_nba.jpg) center/100% 100% no-repeat,linear-gradient(160deg,#0b3550,#061a2e);color:#e8fbff;transition:transform .12s,box-shadow .12s}
.pcn-card:hover{transform:translateY(-3px);box-shadow:0 8px 20px rgba(0,190,255,.35)}
.pcn-face{position:absolute;left:12.4%;right:12.2%;top:10.7%;bottom:20.9%;overflow:hidden}
.pcn-face img{position:absolute;left:0;width:100%;bottom:0;height:80%;object-fit:cover;object-position:50% 18%;filter:drop-shadow(0 4px 8px rgba(0,0,0,.6));animation:pcnfade .35s ease both}
@keyframes pcnfade{from{opacity:0}to{opacity:1}}
.pcn-rank{position:absolute;left:14%;top:11.5%;font-weight:900;font-size:12px;color:#7cecff;text-shadow:0 0 6px rgba(0,200,255,.9);z-index:2}
.pcn-info{position:absolute;left:12.4%;right:12.2%;top:80.7%;height:11.6%;display:flex;flex-direction:column;justify-content:center;gap:2px;padding:0 6px;background:rgba(2,16,32,.9);overflow:hidden;box-sizing:border-box;z-index:2}
.pcn-n{display:flex;align-items:center;justify-content:space-between;gap:4px;min-width:0}
.pcn-n b{font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:#fff}
.pcn-n span{font-size:9px;color:#8fdcf0;white-space:nowrap;display:flex;align-items:center;gap:3px;flex:none}
.pcn-n img.lg{width:12px;height:12px;object-fit:contain}
.pcn-s{display:flex;justify-content:space-between;gap:4px;font-size:10px;font-weight:800;color:#7cecff;white-space:nowrap}
.pcn-s i{font-style:normal;font-size:7.5px;font-weight:700;color:#7aa6b8;margin-right:2px}
.pcn-bad .pcn-rank{color:#ffb454;text-shadow:0 0 6px rgba(255,160,40,.9)}
#pcn-ov{position:fixed;inset:0;z-index:99999;background:rgba(2,10,22,.78);display:flex;align-items:center;justify-content:center;padding:16px}
#pcn-box{position:relative;isolation:isolate;width:min(760px,100%);max-height:92vh;overflow:auto;border-radius:16px;color:#e8fbff;background:var(--pcn-bg,linear-gradient(160deg,#0b2a45,#061a2e));border:1px solid rgba(0,200,255,.45);box-shadow:0 20px 60px rgba(0,0,0,.6),0 0 30px rgba(0,190,255,.25);padding:18px 20px}
#pcn-box>*{position:relative;z-index:1}#pcn-wm{position:absolute!important;z-index:0!important;right:-40px;top:-30px;width:360px;height:360px;object-fit:contain;opacity:.13;pointer-events:none;-webkit-mask-image:linear-gradient(200deg,#000 25%,transparent 80%);mask-image:linear-gradient(200deg,#000 25%,transparent 80%)}
#pcn-x{position:absolute;right:12px;top:12px;width:34px;height:34px;padding:0;border-radius:50%;border:1px solid rgba(124,236,255,.55);background:rgba(2,16,32,.75);color:#e8fbff;cursor:pointer;display:flex;align-items:center;justify-content:center;z-index:5}#pcn-x:hover{background:rgba(124,236,255,.25)}#pcn-x svg{display:block}
.pcn-top{display:flex;gap:16px;align-items:flex-end;margin-bottom:12px}
.pcn-ph{width:150px;height:110px;flex:none;border-radius:12px;background:rgba(0,190,255,.08);border:1px solid rgba(124,236,255,.3);overflow:hidden;position:relative}
.pcn-ph img{position:absolute;inset:0;width:100%;height:100%;object-fit:contain;object-position:50% 100%}
.pcn-nm{font-size:22px;font-weight:900;color:#fff;line-height:1.1}
.pcn-sub{display:flex;gap:8px;align-items:center;flex-wrap:wrap;color:#8fdcf0;font-size:13px;margin-top:6px}
.pcn-sub img{width:20px;height:20px;object-fit:contain}
.pcn-pill{padding:2px 9px;border-radius:999px;font-size:11px;font-weight:800;background:rgba(22,163,74,.25);color:#4ade80}.pcn-pill.o{background:rgba(220,38,38,.25);color:#fca5a5}.pcn-pill.q{background:rgba(245,158,11,.25);color:#fcd34d}
.pcn-h{margin:18px 0 8px;font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:#7cecff;font-weight:800;display:flex;align-items:center;gap:8px}.pcn-h:before{content:"";width:4px;height:14px;border-radius:2px;background:#7cecff}.pcn-h.big{font-size:15px;letter-spacing:.06em;color:#fff;margin-top:20px}
.pcn-g{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px}
.pcn-t{background:rgba(0,190,255,.08);border:1px solid rgba(124,236,255,.22);border-radius:10px;padding:8px 10px;text-align:center}
.pcn-t b{display:block;font-size:20px;color:#fff}.pcn-t span{font-size:10px;color:#7aa6b8;letter-spacing:.06em}
.pcn-t.hi{border-color:#7cecff;background:rgba(0,190,255,.18)}
.pcn-bars{display:flex;align-items:flex-end;gap:6px;height:110px;padding:6px 4px 0;position:relative}
.pcn-bars div{flex:1;display:flex;flex-direction:column;justify-content:flex-end;align-items:center;height:100%;font-size:10px;color:#cfefff}
.pcn-bars div i{display:block;width:100%;max-width:34px;border-radius:4px 4px 0 0;margin-top:2px}
.pcn-bars small{font-size:8.5px;color:#7aa6b8;margin-top:3px;white-space:nowrap}
.pcn-lw{border:1px solid rgba(124,236,255,.3);border-radius:12px;overflow:hidden;background:rgba(2,16,32,.55)}
#pcn-box .pcn-tb{width:100%;border-collapse:collapse;font-size:13px;background:transparent!important}#pcn-box .pcn-tb th{text-align:center;color:#9fe6f7!important;background:rgba(0,190,255,.16)!important;font-size:11px;letter-spacing:.05em;text-transform:uppercase;padding:8px 8px;font-weight:800;position:static}#pcn-box .pcn-tb td{text-align:center;padding:7px 8px;color:#e8fbff!important;background:transparent!important;border-top:1px solid rgba(124,236,255,.14);font-weight:600;white-space:nowrap}#pcn-box .pcn-tb tr:nth-child(even) td{background:rgba(124,236,255,.06)!important}#pcn-box .pcn-tb th:first-child,#pcn-box .pcn-tb td:first-child,#pcn-box .pcn-tb th:nth-child(2),#pcn-box .pcn-tb td:nth-child(2){text-align:left}#pcn-box .pcn-tb td.f{color:#7cecff!important;font-weight:900}#pcn-box .pcn-tb td.w{color:#4ade80!important}#pcn-box .pcn-tb td.l{color:#f87171!important}
@media(max-width:620px){.pcn-g{grid-template-columns:repeat(3,minmax(0,1fr))}.pcn-top{flex-direction:column;align-items:flex-start}}`;
document.head.appendChild(st);
(function(){const l=document.createElement("link");l.rel="preconnect";l.href="https://a.espncdn.com";l.crossOrigin="anonymous";document.head.appendChild(l)})();

const jj=async u=>{const r=await fetch(u);if(!r.ok)throw new Error("HTTP "+r.status);return r.json()};
const CACHE={},TS={},BUSY={};let TEAMS=null;
async function ensure(stat){
 if(CACHE[stat]&&Date.now()-(TS[stat]||0)<300000)return CACHE[stat];
 if(BUSY[stat])return BUSY[stat];
 BUSY[stat]=jj("/api/sp/nba/players?stat="+stat).then(d=>{if(d&&Array.isArray(d.rows)){CACHE[stat]=d.rows;TS[stat]=Date.now()}return CACHE[stat]||[]}).catch(()=>CACHE[stat]||[]).finally(()=>{BUSY[stat]=null;run()});
 return BUSY[stat]}
async function loadTeams(){if(TEAMS)return;TEAMS={};try{const t=await jj("/api/sp/nba/teams");(t.teams||[]).forEach(x=>TEAMS[x.abbr]=x)}catch(e){TEAMS=null}}
const logo=ab=>{const t=TEAMS&&TEAMS[ab];return t&&t.logo?`<img class="lg" alt="" src="${E(t.logo)}" onerror="this.style.visibility='hidden'">`:""};

function where(){
 const p=String(typeof page==="string"?page:"").split(":");
 if(p[0]!=="sp"||p[1]!=="nba")return null;
 const k=p[2];
 if(PAGES[k])return{k,stat:PAGES[k][0],title:PAGES[k][1]};
 if(k==="inj")return{k,stat:"pts",title:"Injuries"};
 if(k==="defense")return{k,stat:"stl",title:"Defense"};
 return null}
function colsFor(v){const w=v.clientWidth||1000;return Math.max(5,Math.min(8,Math.floor((w+12)/202)))}
function shortStatus(s){s=String(s||"");return /out/i.test(s)?"OUT":/doubt/i.test(s)?"DOUBT":/quest/i.test(s)?"QUEST":/day/i.test(s)?"DTD":s.slice(0,6).toUpperCase()}
function pool(stat,n){
 const L=(CACHE[stat]||[]).filter(r=>r&&r.id!=null);if(!L.length)return[];
 const mg=Math.max(...L.map(r=>num(r.gp))),gmin=Math.min(8,Math.floor(mg*.5));
 let f=L.filter(r=>num(r.mpg)>=20&&num(r.gp)>=gmin);
 if(f.length<n)f=L.filter(r=>num(r.mpg)>=10&&num(r.gp)>=Math.min(2,gmin));
 return f}
function byId(stat){const m={};(CACHE[stat]||[]).forEach(r=>m[r.id]=r);return m}
function topStat(stat,n){
 return pool(stat,n).sort((a,b)=>num(b.avg)-num(a.avg)).slice(0,n).map(r=>({id:r.id,name:r.name,team:r.team,pos:r.pos,hs:r.headshot,stat,
  s:[[LAB[stat],fm(r.avg)],["L3",fm(r.last3)],["HIT",Math.round(num(r.hit)*100)+"%"]]}))}
function topInj(n){
 const P=byId("pts"),R=byId("reb"),A=byId("ast");
 return Object.values(P).filter(r=>r.inj).map(r=>({r,w:num(r.avg)+1.2*num((R[r.id]||{}).avg)+1.5*num((A[r.id]||{}).avg)}))
  .filter(o=>num(o.r.mpg)>=12).sort((a,b)=>b.w-a.w).slice(0,n)
  .map(o=>({id:o.r.id,name:o.r.name,team:o.r.team,pos:o.r.pos,hs:o.r.headshot,stat:"pts",bad:1,
   s:[["STATUS",shortStatus(o.r.inj.status)],["PTS",fm(o.r.avg)],["MPG",fm(o.r.mpg)]]}))}
function topDef(n,tab){
 const S=byId("stl"),B=byId("blk");
 if(tab==="steals")return topStat("stl",n);
 if(tab==="blocks")return topStat("blk",n);
 const ids=pool("stl",n).map(r=>r.id);
 return ids.map(id=>({id,w:num((S[id]||{}).avg)+num((B[id]||{}).avg)})).sort((a,b)=>b.w-a.w).slice(0,n).map(o=>{const r=S[o.id];
  return{id:r.id,name:r.name,team:r.team,pos:r.pos,hs:r.headshot,stat:"stl",s:[["STL",fm(r.avg)],["BLK",fm((B[o.id]||{}).avg)],["MPG",fm(r.mpg)]]}})}
function defTab(v){const b=v.querySelector(".sdm-tabs button.on");const t=b?b.textContent.trim().toLowerCase():"team defense";return t.startsWith("steal")?"steals":t.startsWith("block")?"blocks":"team"}

function cardHtml(it,i){
 const img=`<img alt="" decoding="async" src="${E(IMG(it.id))}" data-f="${E(it.hs||"")}|${E(ESPN(it.id))}" data-i="0" onerror="pcnErr(this)">`;
 return `<div class="pcn-card${it.bad?" pcn-bad":""}" data-id="${E(it.id)}" data-stat="${E(it.stat)}"><div class="pcn-face">${img}</div><span class="pcn-rank">#${i+1}</span>
 <div class="pcn-info"><div class="pcn-n"><b>${E(it.name)}</b><span>${logo(it.team)}${E(it.team||"")}${it.pos?" &middot; "+E(it.pos):""}</span></div>
 <div class="pcn-s">${it.s.map(x=>`<span><i>${E(x[0])}</i>${E(x[1])}</span>`).join("")}</div></div></div>`}
window.pcnErr=function(im){const l=(im.dataset.f||"").split("|").filter(Boolean),i=+(im.dataset.i||0);if(i<l.length){im.dataset.i=String(i+1);im.src=l[i]}else im.style.visibility="hidden"};
const BASIS={pts:"season average points",reb:"season average rebounds",ast:"season average assists",fg3:"season average threes",stl:"season average steals",blk:"season average blocks"};

function run(){
 const v=document.getElementById("view");if(!v)return;
 const old=v.querySelector("#pcn"),w=where();
 if(!w){if(old)old.remove();return}
 loadTeams();
 let need=[];
 if(w.k==="inj")need=["pts","reb","ast"];else if(w.k==="defense")need=["stl","blk"];else need=[w.stat];
 need.forEach(s=>{if(!CACHE[s]||Date.now()-(TS[s]||0)>=300000)ensure(s)});
 if(need.some(s=>!CACHE[s]))return;
 const n=colsFor(v);let items,basis,title;
 if(w.k==="inj"){items=topInj(n);title="Injured players";basis="most important players on the injury report, by points, rebounds and assists"}
 else if(w.k==="defense"){const tab=defTab(v);items=topDef(n,tab);title=tab==="steals"?"Steals":tab==="blocks"?"Blocks":"Defense";basis=tab==="team"?"steals plus blocks per game":BASIS[tab==="steals"?"stl":"blk"]}
 else{items=topStat(w.stat,n);title=w.title;basis=BASIS[w.stat]}
 if(!items.length){if(old)old.remove();return}
 const h=v.querySelector("h2")||v.querySelector("h1,h3");if(!h)return;
 let a=h;const nx=h.nextElementSibling;if(nx&&nx.classList.contains("sdm-tabs"))a=nx;
 const sig=w.k+"|"+n+"|"+(TEAMS?1:0)+"|"+JSON.stringify(items.map(i=>[i.id,i.s]));
 let el=old;
 if(!el||el.dataset.sig!==sig){
  const x=document.createElement("section");x.id="pcn";x.className="pcn";x.dataset.sig=sig;
  x.innerHTML=`<div class="pcn-head"><b>Top ${items.length} - ${E(title)}</b><span>${E(basis)} | click a card for the player pop-up | updates automatically</span></div><div class="pcn-row" style="--n:${n}">${items.map(cardHtml).join("")}</div>`;
  if(el)el.replaceWith(x);el=x}
 if(el.previousElementSibling!==a)a.insertAdjacentElement("afterend",el)}

/* ---------- player pop-up ---------- */
const trendTxt=t=>t>=.1?`<span style="color:#4ade80">&#9650; ${Math.round(t*100)}%</span>`:(t<=-.1?`<span style="color:#f87171">&#9660; ${Math.round(-t*100)}%</span>`:"flat");
function closePop(){const o=document.getElementById("pcn-ov");if(o)o.remove();document.removeEventListener("keydown",esc)}
function esc(e){if(e.key==="Escape")closePop()}
async function openPop(id,stat){
 closePop();
 const ov=document.createElement("div");ov.id="pcn-ov";
 ov.innerHTML=`<div id="pcn-box" role="dialog" aria-modal="true"><button id="pcn-x" aria-label="Close"><svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M2 2l10 10M12 2L2 12"/></svg></button><div id="pcn-body">Loading player...</div></div>`;
 ov.addEventListener("click",e=>{if(e.target===ov)closePop()});
 ov.querySelector("#pcn-x").onclick=closePop;
 document.body.appendChild(ov);document.addEventListener("keydown",esc);
 await Promise.all(STATS.map(s=>ensure(s)));
 let logs=[];try{logs=(await jj("/api/sp/nba/player?id="+encodeURIComponent(id))).logs||[]}catch(e){}
 {const cs=Math.max(0,...logs.map(x=>num(x.season)));if(cs)logs=logs.filter(x=>num(x.season)===cs)}
 const body=document.getElementById("pcn-body");if(!body)return;
 const rows={};STATS.forEach(s=>rows[s]=byId(s)[id]);
 const base=rows[stat]||rows.pts||Object.values(rows).find(Boolean);
 if(!base){body.innerHTML="<p>No stats for this player yet.</p>";return}
 {const tm=TEAMS&&TEAMS[base.team],c=tm&&/^#[0-9a-f]{6}$/i.test(tm.color||"")?tm.color:"#1b5fd1",box=document.getElementById("pcn-box");
  if(box){box.style.setProperty("--pcn-bg","linear-gradient(145deg,"+c+"cc 0%,#0a2540 42%,#040f1d 100%)");const o=box.querySelector("#pcn-wm");if(o)o.remove();if(tm&&tm.logo){const im=document.createElement("img");im.id="pcn-wm";im.alt="";im.src=tm.logo;box.prepend(im)}}}
 const ij=base.inj,cls=ij?(/out/i.test(ij.status)?"o":"q"):"";
 const nxt=base.next?`${base.next.home?"vs":"@"} ${E(base.next.opp)}`:"";
 const img=`<img alt="" src="${E(IMG(id))}" data-f="${E(base.headshot||"")}|${E(ESPN(id))}" data-i="0" onerror="pcnErr(this)">`;
 const tiles=STATS.map(s=>`<div class="pcn-t${s===stat?" hi":""}"><b>${rows[s]?fm(rows[s].avg):"-"}</b><span>${LAB[s]}</span></div>`).join("")
  +`<div class="pcn-t"><b>${fm(base.gp)}</b><span>GAMES</span></div><div class="pcn-t"><b>${fm(base.mpg)}</b><span>MIN / GAME</span></div>`;
 const fr=rows[stat]||base,L=logs.slice(0,10).reverse(),avg=num(fr.avg),mx=Math.max(1,...L.map(x=>num(x[stat])),avg);
 const bars=L.length?`<div class="pcn-bars">${L.map(x=>{const v=num(x[stat]);return `<div title="${E(x.day||"")}"><span>${fm(v)}</span><i style="height:${Math.max(4,v/mx*80)}%;background:${v>=avg?"#22c55e":"#ef4444"}"></i><small>${E((x.ha||"")+" "+(x.opp||""))}</small></div>`}).join("")}</div>`:'<p style="color:#7aa6b8">No game log yet.</p>';
 const tbl=logs.length?`<div class="pcn-lw"><table class="pcn-tb"><tr><th>Date</th><th>Opp</th><th>Result</th><th>MIN</th><th>PTS</th><th>REB</th><th>AST</th><th>3PM</th><th>STL</th><th>BLK</th><th>TOV</th></tr>${logs.slice(0,10).map(x=>`<tr><td>${E(x.day||"")}</td><td>${E((x.ha||"")+" "+(x.opp||""))}</td><td class="${/^w/i.test(x.result||"")?"w":/^l/i.test(x.result||"")?"l":""}">${E(x.result||"-")}</td><td>${fm(x.min)}</td>${["pts","reb","ast","fg3","stl","blk","tov"].map(k=>`<td${k===stat?' class="f"':""}>${fm(x[k])}</td>`).join("")}</tr>`).join("")}</table></div>`:"";
 body.innerHTML=`<div class="pcn-top"><div class="pcn-ph">${img}</div><div><div class="pcn-nm">${E(base.name)}</div>
  <div class="pcn-sub">${logo(base.team)}<span>${E(base.team||"")}</span><span>${E(base.pos||"")}</span>${ij?`<span class="pcn-pill ${cls}" title="${E(ij.detail||"")}">${E(ij.status)}${ij.detail?" - "+E(ij.detail):""}</span>`:'<span class="pcn-pill">Healthy</span>'}${nxt?`<span>Next: ${nxt}</span>`:""}</div>
  ${ij&&ij.note?`<div style="margin-top:6px;font-size:12px;color:#cfefff">${E(ij.note)}</div>`:""}</div></div>
  <div class="pcn-h">Season averages</div><div class="pcn-g">${tiles}</div>
  <div class="pcn-h">${LAB[stat]} - last ${L.length} games <span style="color:#7aa6b8;text-transform:none;letter-spacing:0">(green = reached his ${fm(fr.avg)} average)</span></div>${bars}
  <div class="pcn-g" style="margin-top:8px"><div class="pcn-t"><b>${fm(fr.last3)}</b><span>LAST 3</span></div><div class="pcn-t"><b>${Math.round(num(fr.hit)*100)}%</b><span>HIT RATE</span></div><div class="pcn-t"><b>${fm(fr.mx)}</b><span>SEASON HIGH</span></div><div class="pcn-t"><b>${trendTxt(num(fr.trend))}</b><span>TREND</span></div></div>
  ${fr.prior_avg!=null?`<div style="margin-top:6px;font-size:12px;color:#8fdcf0">Last season: ${fm(fr.prior_avg)} per game over ${fm(fr.prior_gp)} games</div>`:""}
  ${tbl?`<div class="pcn-h big">Game log <span style="color:#7aa6b8;font-weight:600;letter-spacing:0;text-transform:none;font-size:12px">last ${Math.min(10,logs.length)} games</span></div>${tbl}`:""}`}
document.addEventListener("click",e=>{const c=e.target.closest&&e.target.closest(".pcn-card");if(!c)return;e.preventDefault();openPop(c.dataset.id,c.dataset.stat)});

let t1=null;const v0=document.getElementById("view");
if(v0)new MutationObserver(()=>{clearTimeout(t1);t1=setTimeout(()=>{try{run()}catch(e){console.log("pcn",e)}},150)}).observe(v0,{childList:true,subtree:true});
window.addEventListener("resize",()=>{clearTimeout(t1);t1=setTimeout(()=>{try{run()}catch(e){}},200)});
setInterval(()=>{try{run()}catch(e){}},3000);
setTimeout(()=>{try{run()}catch(e){}},400);
setInterval(()=>{if(document.hidden||!where())return;Object.keys(TS).forEach(k=>TS[k]=0);run()},300000);
})();
