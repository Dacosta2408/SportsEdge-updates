/* Sports Edge - NHL and MLB Top player cards 1.0
   A row of top players under the header on the NHL pages (Points, Scoring, Assists, Shots, Goalies, Injuries)
   and the MLB pages (Hitters, Batting, Home Runs, Stolen Bases, Runs Batted In, Pitchers, Injuries, Defense).
   Click a card for the player pop-up. Needs /static/playercard_nhl.jpg and /static/playercard_mlb.jpg.
   Off switch: localStorage.hmc_off=1 */
(function(){
try{if(localStorage.getItem("hmc_off")==="1")return}catch(e){}
if(window.__hmc)return;window.__hmc=1;
const E=s=>String(s==null?"":s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const num=x=>{x=Number(x);return isFinite(x)?x:0};
const fm=x=>{if(x==null||x==="")return"-";x=Number(x);if(!isFinite(x))return"-";return Number.isInteger(x)?String(x):String(Math.round(x*100)/100)};
const sp3=x=>{if(x==null||x===""||!isFinite(Number(x)))return"-";return Number(x).toFixed(3).replace(/^0/,"")};
const pc=x=>Math.round(num(x)*100)+"%";
const NHLC={ANA:"#F47A38",BOS:"#FFB81C",BUF:"#3a6fd8",CGY:"#D2001C",CAR:"#CC0000",CHI:"#CF0A2C",COL:"#8a2a4a",CBJ:"#2a5aa8",DAL:"#00A86B",DET:"#CE1126",EDM:"#FF4C00",FLA:"#C8102E",LAK:"#8a8d8f",MIN:"#2a7a4f",MTL:"#AF1E2D",NSH:"#FFB81C",NJD:"#CE1126",NYI:"#00539B",NYR:"#2a6fd0",OTT:"#C8102E",PHI:"#F74902",PIT:"#FFB81C",SEA:"#5ec1d6",SJS:"#2a8a99",STL:"#2a6fd0",TBL:"#2a5fc4",TOR:"#2a62c8",UTA:"#6CACE4",VAN:"#2a7fc0",VGK:"#B4975A",WSH:"#C8102E",WPG:"#2a5aa8"};
const MLBC={ATH:"#2a8a5a",ATL:"#CE1141",AZ:"#A71930",BAL:"#DF4601",BOS:"#BD3039",CHC:"#2a5fc4",CIN:"#C6011F",CLE:"#E31937",COL:"#6a4a9a",CWS:"#8a8d8f",DET:"#FA4616",HOU:"#EB6E1F",KC:"#2a6fd0",LAA:"#BA0021",LAD:"#2a6fd0",MIA:"#00A3E0",MIL:"#FFC52F",MIN:"#D31145",NYM:"#FF5910",NYY:"#3a5a8a",PHI:"#E81828",PIT:"#FDB827",SD:"#9a7a4a",SEA:"#2a9a9a",SF:"#FD5A1E",STL:"#C41E3A",TB:"#8FBCE6",TEX:"#C0111F",TOR:"#2a6fd0",WSH:"#AB0003"};
const MLBKEY={AZ:"ari",CWS:"chw",ATH:"oak"};
const CFG={
 nhl:{name:"NHL",img:"/static/playercard_nhl.jpg",
  pages:{points:{k:"pts",t:"Points",b:"points per game"},scoring:{k:"g",t:"Scoring",b:"goals per game"},assists:{k:"a",t:"Assists",b:"assists per game"},shots:{k:"sog",t:"Shots",b:"shots on goal per game"},goalies:{k:"gk",t:"Goalies",b:"save percentage"},injuries:{inj:1,t:"Injured players",b:"most important players on the injury report, by points and goalie wins"}},
  lists:["pts","g","a","sog","gk"],
  api:s=>"/api/hm/nhl/players?stat="+s,
  logo:t=>"https://assets.nhle.com/logos/nhl/svg/"+t+"_light.svg",
  color:t=>NHLC[t]||"#1b5fd1"},
 mlb:{name:"MLB",img:"/static/playercard_mlb.jpg",
  pages:{hitters:{k:"h",t:"Hitters",b:"hits per game"},batting:{k:"avg",t:"Batting",b:"batting average"},hr:{k:"hr",t:"Home Runs",b:"home runs this season"},sb:{k:"sb",t:"Stolen Bases",b:"stolen bases this season"},rbi:{k:"rbi",t:"Runs Batted In",b:"RBI this season"},pitchers:{k:"k",t:"Pitchers",b:"strikeouts per start"},inj:{inj:1,t:"Injured players",b:"most important players on the injury report, by hits and strikeouts"},defense:{k:"k",def:1,t:"Defense",b:"pitchers with the lowest earned run average (run prevention)"}},
  lists:["h","avg","hr","sb","rbi","k"],
  api:s=>"/api/hm/mlb/players?stat="+s,
  logo:t=>"https://a.espncdn.com/i/teamlogos/mlb/500/"+(MLBKEY[t]||String(t).toLowerCase())+".png",
  color:t=>MLBC[t]||"#1b5fd1"}};
const IMGS={
 nhl:(r,se)=>"https://assets.nhle.com/mugs/nhl/"+se+(se+1)+"/"+r.team+"/"+r.id+".png",
 mlb:r=>"https://img.mlbstatic.com/mlb-photos/image/upload/w_426,q_auto:best/v1/people/"+r.id+"/headshot/silo/current.png"};
const FALL={
 nhl:r=>"https://assets.nhle.com/mugs/nhl/latest/"+r.id+".png",
 mlb:r=>"https://img.mlbstatic.com/mlb-photos/image/upload/d_people:generic:headshot:67:current.png/w_426,q_auto:best/v1/people/"+r.id+"/headshot/67/current"};

const st=document.createElement("style");st.id="hmc-css";
st.textContent=`.hmc{margin:12px 0 16px}
.hmc-head{display:flex;align-items:baseline;gap:10px;margin:0 0 8px;flex-wrap:wrap}.hmc-head b{font-size:15px}.hmc-head span{font-size:12px;color:#8a94a6}
.hmc-row{display:grid;grid-template-columns:repeat(var(--n,5),minmax(0,1fr));gap:12px;padding:2px 2px 6px}
.hmc-card{position:relative;aspect-ratio:848/1264;border-radius:10px;overflow:hidden;cursor:pointer;background:var(--art) center/100% 100% no-repeat,linear-gradient(160deg,#0b3550,#061a2e);color:#e8fbff;transition:transform .12s,box-shadow .12s}
.hmc-card:hover{transform:translateY(-3px);box-shadow:0 8px 20px rgba(0,190,255,.35)}
.hmc-face{position:absolute;left:12.4%;right:12.2%;top:10.7%;bottom:20.9%;overflow:hidden}
.hmc-face img{position:absolute;left:0;width:100%;bottom:0;height:80%;object-fit:cover;object-position:50% 12%;filter:drop-shadow(0 4px 8px rgba(0,0,0,.6));animation:hmcfade .35s ease both}
@keyframes hmcfade{from{opacity:0}to{opacity:1}}
.hmc-rank{position:absolute;left:14%;top:11.5%;font-weight:900;font-size:12px;color:#7cecff;text-shadow:0 0 6px rgba(0,200,255,.9);z-index:2}
.hmc-info{position:absolute;left:12.4%;right:12.2%;top:80.7%;height:11.6%;display:flex;flex-direction:column;justify-content:center;gap:2px;padding:0 6px;background:rgba(2,16,32,.9);overflow:hidden;box-sizing:border-box;z-index:2}
.hmc-n{display:flex;align-items:center;justify-content:space-between;gap:4px;min-width:0}
.hmc-n b{font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:#fff}
.hmc-n span{font-size:9px;color:#8fdcf0;white-space:nowrap;display:flex;align-items:center;gap:3px;flex:none}
.hmc-n img.lg{width:12px;height:12px;object-fit:contain}
.hmc-s{display:flex;justify-content:space-between;gap:4px;font-size:10px;font-weight:800;color:#7cecff;white-space:nowrap}
.hmc-s i{font-style:normal;font-size:7.5px;font-weight:700;color:#7aa6b8;margin-right:2px}
.hmc-bad .hmc-rank{color:#ffb454;text-shadow:0 0 6px rgba(255,160,40,.9)}
#hmc-ov{position:fixed;inset:0;z-index:99999;background:rgba(2,10,22,.78);display:flex;align-items:center;justify-content:center;padding:16px}
#hmc-box{position:relative;isolation:isolate;width:min(760px,100%);max-height:92vh;overflow:auto;border-radius:16px;color:#e8fbff;background:var(--hmc-bg,linear-gradient(160deg,#0b2a45,#061a2e));border:1px solid rgba(0,200,255,.45);box-shadow:0 20px 60px rgba(0,0,0,.6),0 0 30px rgba(0,190,255,.25);padding:18px 20px}
#hmc-box>*{position:relative;z-index:1}#hmc-wm{position:absolute!important;z-index:0!important;right:-40px;top:-30px;width:360px;height:360px;object-fit:contain;opacity:.13;pointer-events:none;-webkit-mask-image:linear-gradient(200deg,#000 25%,transparent 80%);mask-image:linear-gradient(200deg,#000 25%,transparent 80%)}
#hmc-x{position:absolute;right:12px;top:12px;width:34px;height:34px;padding:0;border-radius:50%;border:1px solid rgba(124,236,255,.55);background:rgba(2,16,32,.75);color:#e8fbff;cursor:pointer;display:flex;align-items:center;justify-content:center;z-index:5}#hmc-x:hover{background:rgba(124,236,255,.25)}#hmc-x svg{display:block}
.hmc-top{display:flex;gap:16px;align-items:flex-end;margin-bottom:12px}
.hmc-ph{width:150px;height:120px;flex:none;border-radius:12px;background:rgba(0,190,255,.08);border:1px solid rgba(124,236,255,.3);overflow:hidden;position:relative}
.hmc-ph img{position:absolute;inset:0;width:100%;height:100%;object-fit:contain;object-position:50% 100%}
.hmc-nm{font-size:22px;font-weight:900;color:#fff;line-height:1.1}
.hmc-sub{display:flex;gap:8px;align-items:center;flex-wrap:wrap;color:#8fdcf0;font-size:13px;margin-top:6px}
.hmc-sub img{width:20px;height:20px;object-fit:contain}
.hmc-pill{padding:2px 9px;border-radius:999px;font-size:11px;font-weight:800;background:rgba(22,163,74,.25);color:#4ade80}.hmc-pill.o{background:rgba(220,38,38,.25);color:#fca5a5}.hmc-pill.q{background:rgba(245,158,11,.25);color:#fcd34d}
.hmc-h{margin:18px 0 8px;font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:#7cecff;font-weight:800;display:flex;align-items:center;gap:8px}.hmc-h:before{content:"";width:4px;height:14px;border-radius:2px;background:#7cecff}.hmc-h.big{font-size:15px;letter-spacing:.06em;color:#fff;margin-top:20px}
.hmc-g{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px}
.hmc-t{background:rgba(0,190,255,.08);border:1px solid rgba(124,236,255,.22);border-radius:10px;padding:8px 10px;text-align:center}
.hmc-t b{display:block;font-size:20px;color:#fff}.hmc-t span{font-size:10px;color:#7aa6b8;letter-spacing:.06em}
.hmc-t.hi{border-color:#7cecff;background:rgba(0,190,255,.18)}
.hmc-bars{display:flex;align-items:flex-end;gap:6px;height:110px;padding:6px 4px 0;position:relative}
.hmc-bars div{flex:1;display:flex;flex-direction:column;justify-content:flex-end;align-items:center;height:100%;font-size:10px;color:#cfefff}
.hmc-bars div i{display:block;width:100%;max-width:34px;border-radius:4px 4px 0 0;margin-top:2px}
.hmc-bars small{font-size:8.5px;color:#7aa6b8;margin-top:3px;white-space:nowrap}
.hmc-lw{border:1px solid rgba(124,236,255,.3);border-radius:12px;overflow:auto;background:rgba(2,16,32,.55)}
#hmc-box .hmc-tb{width:100%;border-collapse:collapse;font-size:13px;background:transparent!important}#hmc-box .hmc-tb th{text-align:center;color:#9fe6f7!important;background:rgba(0,190,255,.16)!important;font-size:11px;letter-spacing:.05em;text-transform:uppercase;padding:8px 8px;font-weight:800;position:static}#hmc-box .hmc-tb td{text-align:center;padding:7px 8px;color:#e8fbff!important;background:transparent!important;border-top:1px solid rgba(124,236,255,.14);font-weight:600;white-space:nowrap}#hmc-box .hmc-tb tr:nth-child(even) td{background:rgba(124,236,255,.06)!important}#hmc-box .hmc-tb th:first-child,#hmc-box .hmc-tb td:first-child,#hmc-box .hmc-tb th:nth-child(2),#hmc-box .hmc-tb td:nth-child(2){text-align:left}#hmc-box .hmc-tb td.f{color:#7cecff!important;font-weight:900}#hmc-box .hmc-tb td.w{color:#4ade80!important}#hmc-box .hmc-tb td.l{color:#f87171!important}
@media(max-width:620px){.hmc-g{grid-template-columns:repeat(3,minmax(0,1fr))}.hmc-top{flex-direction:column;align-items:flex-start}}`;
document.head.appendChild(st);
(function(){const l=document.createElement("link");l.rel="preconnect";l.href="https://assets.nhle.com";l.crossOrigin="anonymous";document.head.appendChild(l);const m=document.createElement("link");m.rel="preconnect";m.href="https://img.mlbstatic.com";m.crossOrigin="anonymous";document.head.appendChild(m)})();

const jj=async u=>{const r=await fetch(u);if(!r.ok)throw new Error("HTTP "+r.status);return r.json()};
const CACHE={},TS={},BUSY={},SEASON={nhl:2025,mlb:2026};
async function ensure(sp,stat){
 const key=sp+":"+stat;
 if(CACHE[key]&&Date.now()-(TS[key]||0)<300000)return CACHE[key];
 if(BUSY[key])return BUSY[key];
 BUSY[key]=jj(CFG[sp].api(stat)).then(d=>{if(d&&Array.isArray(d.rows)){CACHE[key]=d.rows;TS[key]=Date.now();if(d.season)SEASON[sp]=d.season}return CACHE[key]||[]}).catch(()=>CACHE[key]||[]).finally(()=>{BUSY[key]=null;run()});
 return BUSY[key]}
async function ensureInj(){
 const key="nhl:inj";
 if(CACHE[key]&&Date.now()-(TS[key]||0)<300000)return;
 if(BUSY[key])return;
 BUSY[key]=jj("/api/nhlinj/all").then(d=>{if(d&&Array.isArray(d.rows)){CACHE[key]=d.rows;TS[key]=Date.now()}}).catch(()=>{if(!CACHE[key])CACHE[key]=[];TS[key]=Date.now()}).finally(()=>{BUSY[key]=null;run()})}
const L=(sp,s)=>CACHE[sp+":"+s]||[];
const byId=(sp,s)=>{const m={};L(sp,s).forEach(r=>m[r.id]=r);return m};
const logo=(sp,t)=>t?`<img class="lg" alt="" src="${E(CFG[sp].logo(t))}" onerror="this.style.visibility='hidden'">`:"";

function where(){
 const p=String(typeof page==="string"?page:"").split(":");
 if(p[0]!=="sp"||!CFG[p[1]])return null;
 const c=CFG[p[1]].pages[p[2]];if(!c)return null;
 return Object.assign({sp:p[1],pg:p[2]},c)}
function colsFor(v){const w=v.clientWidth||1000;return Math.max(5,Math.min(8,Math.floor((w+12)/202)))}
function shortStatus(s){s=String(s||"");return /injured reserve|^ir$|ltir/i.test(s)?"IR":/out/i.test(s)?"OUT":/doubt/i.test(s)?"DOUBT":/quest/i.test(s)?"QUEST":/\d+-day/i.test(s)?"IL":/day/i.test(s)?"DTD":s.slice(0,6).toUpperCase()}
const isInj=i=>i&&i.status&&!/^(active|healthy)$/i.test(i.status);
function qual(rows,frac,cap){
 const mg=Math.max(1,...rows.map(r=>num(r.gp))),gmin=Math.max(1,Math.min(cap,Math.floor(mg*frac)));
 return rows.filter(r=>r&&r.id!=null&&num(r.gp)>=gmin)}
function mk(sp,r,stat,s,extra){return Object.assign({sp,id:r.id,name:r.name,team:r.team,pos:r.pos,stat,s,season:SEASON[sp]},extra||{})}

/* ---------- which players go on the cards ---------- */
function nhlTop(w,n){
 const k=w.k,rows=L("nhl",k);
 if(k==="gk"){
  let f=qual(rows,.4,8);f=f.filter(r=>r.svp!=null).sort((a,b)=>num(b.svp)-num(a.svp)).slice(0,n);
  return f.map(r=>mk("nhl",r,"gk",[["SV%",sp3(r.svp)],["GAA",r.gaa==null?"-":num(r.gaa).toFixed(2)],["W",fm(r.wins)]]))}
 const lab={pts:"PTS",g:"G",a:"A",sog:"SOG"}[k];
 let f=qual(rows,.5,10);
 return f.sort((a,b)=>num(b.avg)-num(a.avg)).slice(0,n).map(r=>mk("nhl",r,k,[[lab+"/G",fm(r.avg)],["L3",fm(r.last3)],["HIT",pc(r.hit)]]))}
const nm=n=>String(n||"").normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase();
function nhlKey(name){const p=nm(name).replace(/\b(jr|sr|ii|iii)\.?$/,"").replace(/[^a-z .'-]/g,"").trim().split(/\s+/);const last=p.slice(1).join("").replace(/[^a-z]/g,"")||p[0].replace(/[^a-z]/g,"");return(p[0]||"").charAt(0)+"|"+last}
function nhlInj(n){
 const inj=CACHE["nhl:inj"];if(!inj)return null;
 const sk=L("nhl","pts"),gk=L("nhl","gk");if(!sk.length&&!gk.length)return[];
 const idx={},idxT={};
 sk.concat(gk).forEach(r=>{const k=nhlKey(r.name);(idx[k]=idx[k]||[]).push(r);idxT[k+"|"+r.team]=r});
 const out=[],seen={};
 inj.forEach(i=>{
  const k=nhlKey(i.player);let r=idxT[k+"|"+i.abbr];
  if(!r&&idx[k]&&idx[k].length===1)r=idx[k][0];
  if(!r||seen[r.id])return;seen[r.id]=1;
  const g=r.pos==="G";
  const score=g?num(r.wins)*3:num(r.total);
  out.push({r,i,g,score})});
 return out.filter(o=>num(o.r.gp)>=3).sort((a,b)=>b.score-a.score).slice(0,n).map(o=>mk("nhl",o.r,o.g?"gk":"pts",
  [["STATUS",shortStatus(o.i.status)],o.g?["SV%",sp3(o.r.svp)]:["PTS/G",fm(o.r.avg)],["GP",fm(o.r.gp)]],{bad:1,inj:{status:o.i.status,detail:o.i.detail,note:o.i.note}}))}
function mlbTop(w,n){
 const k=w.k;
 if(k==="k"){
  let f=qual(L("mlb","k"),.5,5);
  if(w.def)return f.filter(r=>r.era!=null).sort((a,b)=>num(a.era)-num(b.era)).slice(0,n).map(r=>mk("mlb",r,"k",[["ERA",num(r.era).toFixed(2)],["K/G",fm(r.avg)],["IP",fm(r.ip)]],{def:1}));
  return f.sort((a,b)=>num(b.avg)-num(a.avg)).slice(0,n).map(r=>mk("mlb",r,"k",[["K/G",fm(r.avg)],["ERA",r.era==null?"-":num(r.era).toFixed(2)],["IP",fm(r.ip)]]))}
 const rows=L("mlb",k);
 let f=qual(rows,.6,12);
 if(k==="avg")return f.sort((a,b)=>num(b.avg)-num(a.avg)).slice(0,n).map(r=>mk("mlb",r,"avg",[["AVG",sp3(r.avg)],["L10",sp3(r.l10)],["HIT",pc(r.hit)]]));
 if(k==="h")return f.sort((a,b)=>num(b.avg)-num(a.avg)).slice(0,n).map(r=>mk("mlb",r,"h",[["H/G",fm(r.avg)],["L3",fm(r.last3)],["HIT",pc(r.hit)]]));
 const lab={hr:"HR",sb:"SB",rbi:"RBI"}[k];
 return f.sort((a,b)=>num(b.total)-num(a.total)||num(b.avg)-num(a.avg)).slice(0,n).map(r=>mk("mlb",r,k,[[lab,fm(r.total)],["L3",fm(r.last3)],["HIT",pc(r.hit)]]))}
function mlbInj(n){
 const H=L("mlb","h"),P=L("mlb","k");if(!H.length&&!P.length)return[];
 const all=[];
 qual(H,.3,8).forEach(r=>{if(isInj(r.inj))all.push({r,st:"h",sc:num(r.total)})});
 qual(P,.3,3).forEach(r=>{if(isInj(r.inj))all.push({r,st:"k",sc:num(r.total)})});
 return all.sort((a,b)=>b.sc-a.sc).slice(0,n).map(o=>mk("mlb",o.r,o.st,[["STATUS",shortStatus(o.r.inj.status)],o.st==="k"?["K/G",fm(o.r.avg)]:["H/G",fm(o.r.avg)],["GP",fm(o.r.gp)]],{bad:1,inj:o.r.inj}))}

function cardHtml(it,i){
 const img=`<img alt="" decoding="async" src="${E(IMGS[it.sp](it,it.season))}" data-f="${E(FALL[it.sp](it))}" data-i="0" onerror="hmcErr(this)">`;
 return `<div class="hmc-card${it.bad?" hmc-bad":""}" style="--art:url(${CFG[it.sp].img})" data-sp="${it.sp}" data-id="${E(it.id)}" data-stat="${E(it.stat)}" data-def="${it.def?1:0}"><div class="hmc-face">${img}</div><span class="hmc-rank">#${i+1}</span>
 <div class="hmc-info"><div class="hmc-n"><b>${E(it.name)}</b><span>${logo(it.sp,it.team)}${E(it.team||"")}${it.pos?" &middot; "+E(it.pos):""}</span></div>
 <div class="hmc-s">${it.s.map(x=>`<span><i>${E(x[0])}</i>${E(x[1])}</span>`).join("")}</div></div></div>`}
window.hmcErr=function(im){const l=(im.dataset.f||"").split("|").filter(Boolean),i=+(im.dataset.i||0);if(i<l.length){im.dataset.i=String(i+1);im.src=l[i]}else im.style.visibility="hidden"};

function note(v,w,msg){
 const h=v.querySelector("h2")||v.querySelector("h1,h3");if(!h)return;
 let el=v.querySelector("#hmc");
 if(!el||el.dataset.sig!=="note|"+msg){const x=document.createElement("section");x.id="hmc";x.className="hmc";x.dataset.sig="note|"+msg;x.innerHTML=`<div class="hmc-head"><span>Top player cards 1.1: ${E(msg)}</span></div>`;if(el)el.replaceWith(x);el=x}
 let a=h;const nx=h.nextElementSibling;if(nx&&nx.classList.contains("sdm-tabs"))a=nx;
 if(el.previousElementSibling!==a)a.insertAdjacentElement("afterend",el)}
function run(){
 const v=document.getElementById("view");if(!v)return;
 const old=v.querySelector("#hmc"),w=where();
 if(!w){if(old)old.remove();return}
 const sp=w.sp;
 let need=[];
 if(w.inj){need=sp==="nhl"?["pts","gk"]:["h","k"];if(sp==="nhl")ensureInj()}else need=[w.k];
 need.forEach(s=>{if(!CACHE[sp+":"+s]||Date.now()-(TS[sp+":"+s]||0)>=300000)ensure(sp,s)});
 if(need.some(s=>!CACHE[sp+":"+s])){note(v,w,"Loading player data for the cards...");return}
 const n=colsFor(v);let items;
 if(w.inj)items=sp==="nhl"?nhlInj(n):mlbInj(n);else items=sp==="nhl"?nhlTop(w,n):mlbTop(w,n);
 if(!items||!items.length){note(v,w,"No players qualify for the cards yet ("+need.map(s=>s+": "+L(sp,s).length+" rows").join(", ")+").");return}
 const h=v.querySelector("h2")||v.querySelector("h1,h3");if(!h)return;
 let a=h;const nx=h.nextElementSibling;if(nx&&nx.classList.contains("sdm-tabs"))a=nx;
 const sig=sp+"|"+w.pg+"|"+n+"|"+JSON.stringify(items.map(i=>[i.id,i.s]));
 let el=old;
 if(!el||el.dataset.sig!==sig){
  const x=document.createElement("section");x.id="hmc";x.className="hmc";x.dataset.sig=sig;
  x.innerHTML=`<div class="hmc-head"><b>Top ${items.length} - ${E(w.t)}</b><span>${E(w.b)} | click a card for the player pop-up | updates automatically</span></div><div class="hmc-row" style="--n:${n}">${items.map(cardHtml).join("")}</div>`;
  if(el)el.replaceWith(x);el=x}
 if(el.previousElementSibling!==a)a.insertAdjacentElement("afterend",el)}

/* ---------- player pop-up ---------- */
const trendTxt=t=>t>=.1?`<span style="color:#4ade80">&#9650; ${Math.round(t*100)}%</span>`:(t<=-.1?`<span style="color:#f87171">&#9660; ${Math.round(-t*100)}%</span>`:"flat");
function closePop(){const o=document.getElementById("hmc-ov");if(o)o.remove();document.removeEventListener("keydown",esc)}
function esc(e){if(e.key==="Escape")closePop()}
const tile=(v,l,hi)=>`<div class="hmc-t${hi?" hi":""}"><b>${v}</b><span>${l}</span></div>`;
const th=(cols)=>cols.map(c=>`<th>${c[0]}</th>`).join("");
async function openPop(sp,id,stat,def){
 closePop();
 const ov=document.createElement("div");ov.id="hmc-ov";
 ov.innerHTML=`<div id="hmc-box" role="dialog" aria-modal="true"><button id="hmc-x" aria-label="Close"><svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M2 2l10 10M12 2L2 12"/></svg></button><div id="hmc-body">Loading player...</div></div>`;
 ov.addEventListener("click",e=>{if(e.target===ov)closePop()});
 ov.querySelector("#hmc-x").onclick=closePop;
 document.body.appendChild(ov);document.addEventListener("keydown",esc);
 const cfg=CFG[sp],gk=sp==="nhl"&&stat==="gk",pit=sp==="mlb"&&stat==="k";
 const lists=sp==="nhl"?(gk?["gk"]:["pts","g","a","sog"]):(pit?["k"]:["h","avg","hr","sb","rbi"]);
 await Promise.all(lists.map(s=>ensure(sp,s)));
 let logs=[];
 try{logs=(await jj(sp==="nhl"?"/api/hm/nhl/player?id="+encodeURIComponent(id)+(gk?"&gk=1":""):"/api/hm/mlb/player?id="+encodeURIComponent(id))).logs||[]}catch(e){}
 if(sp==="mlb")logs=logs.filter(x=>pit?x.role==="pit":x.role==="bat");
 const body=document.getElementById("hmc-body");if(!body)return;
 const rows={};lists.forEach(s=>rows[s]=byId(sp,s)[id]);
 const base=rows[stat]||Object.values(rows).find(Boolean);
 if(!base){body.innerHTML="<p>No stats for this player yet.</p>";return}
 const box=document.getElementById("hmc-box"),c=cfg.color(base.team);
 if(box){box.style.setProperty("--hmc-bg","linear-gradient(145deg,"+c+"cc 0%,#0a2540 42%,#040f1d 100%)");const im=document.createElement("img");im.id="hmc-wm";im.alt="";im.src=cfg.logo(base.team);im.onerror=function(){this.remove()};box.prepend(im)}
 let ij=base.inj;
 if(sp==="nhl"){const arr=CACHE["nhl:inj"]||[];const k=nhlKey(base.name);const m=arr.find(i=>nhlKey(i.player)===k&&(!i.abbr||i.abbr===base.team));if(m)ij={status:m.status,detail:m.detail,note:m.note}}
 if(ij&&!isInj(ij))ij=null;
 const cls=ij?(/out|injured|ir/i.test(ij.status)?"o":"q"):"";
 const nxt=base.next?`${base.next.home?"vs":"@"} ${E(base.next.opp)}`:"";
 const img=`<img alt="" src="${E(IMGS[sp](base,SEASON[sp]))}" data-f="${E(FALL[sp](base))}" data-i="0" onerror="hmcErr(this)">`;
 /* tiles, chart field and game-log columns per player type */
 let tiles,cf,cl,thr,good,cols,fr=base;
 const logV=(k)=>logs.map(x=>num(x[k]));
 if(gk){
  tiles=tile(sp3(base.svp),"SAVE %",1)+tile(base.gaa==null?"-":num(base.gaa).toFixed(2),"GAA")+tile(fm(base.avg),"SAVES / GAME")+tile(fm(base.wins),"WINS")+tile(fm(base.gp),"GAMES")+tile(fm(base.total),"TOTAL SAVES");
  cf="sv";cl="Saves";good=x=>x.sa?(x.sv/x.sa)>=.9:true;thr="a .900 save percentage or better";
  cols=[["Date",x=>E(x.day||"")],["Opp",x=>E(x.opp||"")],["SV",x=>fm(x.sv),1],["SA",x=>fm(x.sa)],["GA",x=>fm(x.ga)],["SV%",x=>x.sa?sp3(x.sv/x.sa):"-"],["Dec",x=>E(x.dec||"-"),0,x=>/^w/i.test(x.dec||"")?"w":/^l|^o/i.test(x.dec||"")?"l":""]];
 }else if(sp==="nhl"){
  const r=k=>rows[k]?fm(rows[k].avg):"-";
  tiles=tile(r("pts"),"PTS / GAME",stat==="pts")+tile(r("g"),"GOALS / GAME",stat==="g")+tile(r("a"),"ASSISTS / GAME",stat==="a")+tile(r("sog"),"SHOTS / GAME",stat==="sog")+tile(fm(base.gp),"GAMES")+tile(fm(base.toi),"TOI / GAME");
  fr=rows[stat]||base;cf=stat;cl={pts:"Points",g:"Goals",a:"Assists",sog:"Shots"}[stat];const avg=num(fr.avg);const line=stat==="sog"?Math.max(1,fr.line||Math.round(avg)):1;
  good=(x)=>num(x[cf])>=line;thr=stat==="sog"?"his typical shot total":"at least one";
  cols=[["Date",x=>E(x.day||"")],["Opp",x=>E(x.opp||"")],["TOI",x=>x.toi==null?"-":(+x.toi).toFixed(1)],["G",x=>fm(x.g),stat==="g"],["A",x=>fm(x.a),stat==="a"],["PTS",x=>fm(x.pts),stat==="pts"],["SOG",x=>fm(x.sog),stat==="sog"]];
 }else if(pit){
  const wins=logs.reduce((s,x)=>s+num(x.w),0);
  tiles=tile(fm(base.avg),"K / START",!def)+tile(base.era==null?"-":num(base.era).toFixed(2),"ERA",!!def)+tile(fm(base.ip),"IP / START")+tile(fm(base.gp),"STARTS")+tile(fm(base.total),"TOTAL K")+tile(logs.length?String(wins):"-","WINS");
  cf="k";cl="Strikeouts";const avg=num(base.avg);good=x=>num(x.k)>=avg;thr="his "+fm(avg)+" strikeout average";
  cols=[["Date",x=>E(x.day||"")],["Opp",x=>E(x.opp||"")],["IP",x=>E(x.ip||"-")],["K",x=>fm(x.k),1],["ER",x=>fm(x.er)],["H",x=>fm(x.ha)],["BB",x=>fm(x.bb)],["NP",x=>fm(x.np)],["W",x=>num(x.w)?"W":"-",0,x=>num(x.w)?"w":""]];
 }else{
  const o=k=>rows[k];
  tiles=tile(o("h")?fm(o("h").avg):"-","HITS / GAME",stat==="h")+tile(o("avg")?sp3(o("avg").avg):"-","AVG",stat==="avg")+tile(o("hr")?fm(o("hr").total):"-","HOME RUNS",stat==="hr")+tile(o("rbi")?fm(o("rbi").total):"-","RBI",stat==="rbi")+tile(o("sb")?fm(o("sb").total):"-","STOLEN BASES",stat==="sb")+tile(fm(base.gp),"GAMES");
  fr=rows[stat]||base;cf=stat==="avg"?"h":stat;cl={h:"Hits",hr:"Home runs",sb:"Stolen bases",rbi:"RBI"}[cf];
  const avg=logs.length?logs.reduce((s,x)=>s+num(x[cf]),0)/logs.length:0;good=x=>num(x[cf])>=Math.max(avg,cf==="h"?1:0.0001);thr=cf==="h"?"at least one hit":"at least one";
  cols=[["Date",x=>E(x.day||"")],["Opp",x=>E(x.opp||"")],["AB",x=>fm(x.ab)],["H",x=>fm(x.h),cf==="h"],["R",x=>fm(x.r)],["RBI",x=>fm(x.rbi),cf==="rbi"],["HR",x=>fm(x.hr),cf==="hr"],["SB",x=>fm(x.sb),cf==="sb"],["BB",x=>fm(x.bb)],["SO",x=>fm(x.so)]];
 }
 const shown=logs.slice(0,10),bl=shown.slice().reverse(),mx=Math.max(1,...bl.map(x=>num(x[cf])));
 const bars=bl.length?`<div class="hmc-bars">${bl.map(x=>{const v=num(x[cf]);return `<div title="${E(x.day||"")}"><span>${fm(v)}</span><i style="height:${Math.max(4,v/mx*80)}%;background:${good(x)?"#22c55e":"#ef4444"}"></i><small>${E(x.opp||"")}</small></div>`}).join("")}</div>`:'<p style="color:#7aa6b8">No game log yet.</p>';
 const tbl=shown.length?`<div class="hmc-lw"><table class="hmc-tb"><tr>${th(cols)}</tr>${shown.map(x=>`<tr>${cols.map(c=>`<td class="${(c[2]?"f ":"")+(c[3]?c[3](x):"")}">${c[1](x)}</td>`).join("")}</tr>`).join("")}</table></div>`:"";
 const l3=gk?sp3(base.l3svp):(sp==="mlb"&&stat==="avg"?sp3(fr.last3):fm(fr.last3));
 const lt=gk?"LAST 3 SV%":"LAST 3";const hl=gk?"QUALITY %":"HIT RATE";
 body.innerHTML=`<div class="hmc-top"><div class="hmc-ph">${img}</div><div><div class="hmc-nm">${E(base.name)}</div>
  <div class="hmc-sub">${logo(sp,base.team)}<span>${E(base.team||"")}</span><span>${E(base.pos||"")}</span>${ij?`<span class="hmc-pill ${cls}" title="${E(ij.detail||"")}">${E(ij.status)}${ij.detail?" - "+E(ij.detail):""}</span>`:'<span class="hmc-pill">Healthy</span>'}${nxt?`<span>Next: ${nxt}</span>`:""}</div>
  ${ij&&ij.note?`<div style="margin-top:6px;font-size:12px;color:#cfefff">${E(ij.note)}</div>`:""}</div></div>
  <div class="hmc-h">Season</div><div class="hmc-g">${tiles}</div>
  <div class="hmc-h">${E(cl)} - last ${bl.length} games <span style="color:#7aa6b8;text-transform:none;letter-spacing:0">(green = ${E(thr)})</span></div>${bars}
  <div class="hmc-g" style="margin-top:8px">${tile(l3,lt)}${tile(pc(fr.hit),hl)}${tile(fm(fr.mx),"SEASON HIGH")}${tile(trendTxt(num(fr.trend)),"TREND")}</div>
  ${tbl?`<div class="hmc-h big">Game log <span style="color:#7aa6b8;font-weight:600;letter-spacing:0;text-transform:none;font-size:12px">last ${shown.length} games</span></div>${tbl}`:""}`}
document.addEventListener("click",e=>{const c=e.target.closest&&e.target.closest(".hmc-card");if(!c)return;e.preventDefault();openPop(c.dataset.sp,c.dataset.id,c.dataset.stat,c.dataset.def==="1")});

let t1=null;const v0=document.getElementById("view");
if(v0)new MutationObserver(()=>{clearTimeout(t1);t1=setTimeout(()=>{try{run()}catch(e){console.log("hmc",e);try{const v=document.getElementById("view"),w=where();if(v&&w)note(v,w,"error - "+(e&&e.message||e))}catch(x){}}},150)}).observe(v0,{childList:true,subtree:true});
window.addEventListener("resize",()=>{clearTimeout(t1);t1=setTimeout(()=>{try{run()}catch(e){}},200)});
setInterval(()=>{try{run()}catch(e){try{const v=document.getElementById("view"),w=where();if(v&&w)note(v,w,"error - "+(e&&e.message||e))}catch(x){}}},3000);
setTimeout(()=>{try{run()}catch(e){}},400);
setInterval(()=>{if(document.hidden||!where())return;Object.keys(TS).forEach(k=>TS[k]=0);run()},300000);
})();
