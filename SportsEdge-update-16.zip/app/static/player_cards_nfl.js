/* Sports Edge - NFL Top player cards 1.2
   A row of top players under the header on Quarterbacks, Receivers, Rushing, Injuries, Defense and Special Teams.
   The row fills the screen width (5 to 8 cards). Keeps the page header and the row when "Week by week" is selected.
   Also tidies the Settings page buttons and merges the three Phone sections into one panel.
   Needs /static/playercard_nfl.jpg. Off switches: localStorage.pc5_off=1 (cards), localStorage.sp_off=1 (Settings polish). */
(function(){
const E=s=>String(s==null?"":s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const flag=k=>{try{return localStorage.getItem(k)==="1"}catch(e){return false}};

/* ================= Settings polish (CSS only) ================= */
if(!flag("sp_off")&&!document.getElementById("sp-css")){
 const s=document.createElement("style");s.id="sp-css";
 s.textContent=`
.r310-menu{display:flex;flex-wrap:wrap;align-items:center;gap:8px;padding:12px 0 14px;border-bottom:1px solid var(--line)}
.r310-menu h2{flex:0 0 100%;margin:0 0 6px}
.r310-menu a{display:inline-flex;align-items:center;justify-content:center;box-sizing:border-box;height:34px;padding:0 16px;border-radius:999px;border:1px solid var(--line)!important;background:var(--card);color:var(--ink)!important;font-weight:700;font-size:13px;line-height:1;white-space:nowrap;cursor:pointer;text-decoration:none}
.r310-menu a:hover{border-color:#2563eb!important;color:#2563eb!important}
.r310-row{gap:12px}
.r310-row .nm{flex:0 0 150px}
.r310-row .r310-b{flex:0 0 auto;box-sizing:border-box;min-width:140px;height:34px;padding:0 14px;text-align:center;font-weight:700;border-radius:10px}
.r310-key .r310-b{min-width:84px}
#se-app-updates .srow,#se-online .srow{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin:8px 0}
#se-app-updates button,#se-online button{height:34px;padding:0 14px;border-radius:10px;font-weight:700}
[data-r310="phone"]{margin:0!important;border-radius:0!important;border-top:1px dashed var(--line)!important;box-shadow:none!important}
:not([data-r310="phone"])+[data-r310="phone"]{margin-top:16px!important;border-top:1px solid var(--line)!important;border-top-left-radius:16px!important;border-top-right-radius:16px!important}
[data-r310="phone"]:has(+ :not([data-r310="phone"])),[data-r310="phone"]:last-child{border-bottom-left-radius:16px!important;border-bottom-right-radius:16px!important}
#pqr{padding-top:12px!important}`;
 document.head.appendChild(s)}

/* ================= Top player cards ================= */
if(flag("pc5_off"))return;
if(window.__pc5)return;window.__pc5=1;
const num=x=>{x=Number(x);return isFinite(x)?x:0};
const fm=x=>{if(x==null||x==="")return"-";x=Number(x);if(!isFinite(x))return"-";return Number.isInteger(x)?String(x):String(Math.round(x*10)/10)};
const HURT=/out|doubt|quest|day|reserve|\bir\b|susp/i;
const IMG=id=>"https://a.espncdn.com/combiner/i?img=/i/headshots/nfl/players/full/"+id+".png&w=240&h=175";
const ESPN=id=>"https://a.espncdn.com/i/headshots/nfl/players/full/"+id+".png";
const PORT=id=>"/api/edge_auto/portrait/nfl_player_"+id+".png";
const LG=a=>(typeof logo==="function"&&a)?logo(a):"";
const TITLE={qb:"Quarterbacks",receivers:"Receivers",rushing:"Rushing",inj:"Injuries",def:"Defense",st:"Special Teams"};
const BASIS={qb:"by HitScore",receivers:"by HitScore",rushing:"by HitScore",inj:"most important players on the injury report",def:"by total tackles"};
const STT={kickers:{t:"Kickers",key:"kickers",sort:"pts",cols:[["PTS","pts"],["FG%","fgpct"],["LNG","long"]]},
 punters:{t:"Punters",key:"punters",sort:"yds",cols:[["PUNTS","no"],["AVG","avg"],["IN20","in20"]]},
 kr:{t:"Kick returns",key:"kick_returners",sort:"yds",cols:[["RET","no"],["YDS","yds"],["AVG","avg"]]},
 pr:{t:"Punt returns",key:"punt_returners",sort:"yds",cols:[["RET","no"],["YDS","yds"],["AVG","avg"]]}};

(function(){
 const l=document.createElement("link");l.rel="preconnect";l.href="https://a.espncdn.com";l.crossOrigin="anonymous";document.head.appendChild(l);
 if(document.getElementById("pc5-css"))return;const s=document.createElement("style");s.id="pc5-css";
 s.textContent=`.pc5{margin:12px 0 16px}
.pc5-head{display:flex;align-items:baseline;gap:10px;margin:0 0 8px;flex-wrap:wrap}.pc5-head b{font-size:15px}.pc5-head span{font-size:12px;color:#8a94a6}
.pc5-row{display:grid;grid-template-columns:repeat(var(--n,5),minmax(0,1fr));gap:12px;padding:2px 2px 6px}
.pc5-card{position:relative;aspect-ratio:848/1264;border-radius:10px;overflow:hidden;background:url(/static/playercard_nfl.jpg) center/100% 100% no-repeat,linear-gradient(160deg,#0b3550,#061a2e);color:#e8fbff;transition:transform .12s,box-shadow .12s}
.pc5-card:hover{transform:translateY(-3px);box-shadow:0 8px 20px rgba(0,190,255,.35)}
.pc5-face{position:absolute;left:12.6%;right:12.2%;top:10.2%;bottom:20.7%;overflow:hidden}
.pc5-face img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:50% 12%;filter:drop-shadow(0 4px 8px rgba(0,0,0,.55));animation:pc5fade .35s ease both}
@keyframes pc5fade{from{opacity:0}to{opacity:1}}
.pc5-face::after{content:"";position:absolute;left:0;right:0;bottom:0;height:22%;background:linear-gradient(180deg,transparent,rgba(2,16,32,.75))}
.pc5-rank{position:absolute;left:14%;top:11%;font-weight:900;font-size:12px;color:#7cecff;text-shadow:0 0 6px rgba(0,200,255,.9);z-index:2}
.pc5-info{position:absolute;left:12.6%;right:12.2%;top:80.9%;height:11.4%;display:flex;flex-direction:column;justify-content:center;gap:2px;padding:0 6px;background:rgba(2,16,32,.88);overflow:hidden;box-sizing:border-box;z-index:2}
.pc5-n{display:flex;align-items:center;justify-content:space-between;gap:4px;min-width:0}
.pc5-n b{font-size:11px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:#fff}
.pc5-n span{font-size:9px;color:#8fdcf0;white-space:nowrap;display:flex;align-items:center;gap:3px;flex:none}
.pc5-n img.logo{width:12px;height:12px}
.pc5-s{display:flex;justify-content:space-between;gap:4px;font-size:10px;font-weight:800;color:#7cecff;white-space:nowrap}
.pc5-s i{font-style:normal;font-size:7.5px;font-weight:700;color:#7aa6b8;margin-right:2px}
.pc5-bad .pc5-rank{color:#ffb454;text-shadow:0 0 6px rgba(255,160,40,.9)}`;
 document.head.appendChild(s)})();

/* image loading: smaller ESPN image first, then the full one, then the app's own cut-out */
window.pc5Err=function(im){const l=(im.dataset.f||"").split("|").filter(Boolean),i=+(im.dataset.i||0);if(i<l.length){im.dataset.i=String(i+1);im.src=l[i]}else im.style.visibility="hidden"};
const KEEP=new Map();
function warm(id){if(id==null)return;const u=IMG(id);if(KEEP.has(u))return;const i=new Image();i.decoding="async";i.src=u;KEEP.set(u,i)}
function warmAll(){
 if(typeof ALL==="undefined"||!ALL)return;
 ["qb","receivers","rushing"].forEach(g=>(ALL[g]||[]).slice().sort((a,b)=>num(b.score)-num(a.score)).slice(0,14).forEach(r=>warm(r.id)));
 ["qb","receivers","rushing"].forEach(g=>(ALL[g]||[]).filter(r=>r&&r.injury&&HURT.test(r.injury)).slice(0,14).forEach(r=>warm(r.id)))}
function warmDef(){if(!DEFD)return;[(DEFD.defense||[]).slice().sort((a,b)=>num(b.tot)-num(a.tot)).slice(0,14),DEFD.kickers||[],DEFD.punters||[],DEFD.kick_returners||[],DEFD.punt_returners||[]].forEach(L=>L.slice(0,14).forEach(r=>warm(r.id)))}

function kind(v){
 try{if(/^sp:(nba|nhl|mlb)/.test(String(page)))return null}catch(e){}
 const h=v.querySelector("h1,h2,h3");if(!h)return null;
 const t=h.textContent.trim().toLowerCase();
 if(t.startsWith("quarterbacks"))return"qb";
 if(t.startsWith("receivers"))return"receivers";
 if(t.startsWith("rushing"))return"rushing";
 if(/^(players?\s*[-:]?\s*)?injur/.test(t))return"inj";
 if(t.startsWith("defense"))return"def";
 if(t.startsWith("special teams"))return"st";
 return null}
function colsFor(v){const w=v.clientWidth||1000;return Math.max(5,Math.min(8,Math.floor((w+12)/202)))}

function topGroup(g,n){
 const L=(typeof ALL!=="undefined"&&ALL[g])||[];
 return L.filter(r=>r&&r.id!=null).slice().sort((a,b)=>num(b.score)-num(a.score)).slice(0,n)
  .map(r=>({id:r.id,name:r.name,team:r.team,pos:r.pos||"",g,s:[["AVG",fm(r.avg)],["L3",fm(r.last3)],["HS",fm(r.score)]]}))}
function shortStatus(s){s=String(s||"");return /reserve|\bir\b/i.test(s)?"IR":/out/i.test(s)?"OUT":/doubt/i.test(s)?"DOUBT":/quest/i.test(s)?"QUEST":/day/i.test(s)?"DTD":/susp/i.test(s)?"SUSP":s.slice(0,6).toUpperCase()}
function topInj(n){
 if(typeof ALL==="undefined")return[];
 const seen=new Set(),pool=[];
 ["qb","receivers","rushing"].forEach(g=>{const L=ALL[g]||[],mx=Math.max(1,...L.map(r=>num(r.avg)));
  L.forEach(r=>{if(!r||r.id==null||seen.has(r.id)||!r.injury||!HURT.test(r.injury))return;seen.add(r.id);pool.push({r,g,w:num(r.avg)/mx})})});
 return pool.sort((a,b)=>b.w-a.w).slice(0,n).map(o=>({id:o.r.id,name:o.r.name,team:o.r.team,pos:o.r.pos||"",g:o.g,bad:1,s:[["STATUS",shortStatus(o.r.injury)],["AVG",fm(o.r.avg)],["POS",o.r.pos||"-"]]}))}

let DEFD=null,DEFT=0,DEFB=false;
function loadDef(){
 if(DEFB||Date.now()-DEFT<300000)return;DEFB=true;
 fetch("/api/defense/players").then(r=>{if(!r.ok)throw 0;return r.json()}).then(d=>{DEFD=d;warmDef()}).catch(()=>{}).finally(()=>{DEFT=Date.now();DEFB=false;run()})}
function topDef(n){
 return((DEFD&&DEFD.defense)||[]).slice().sort((a,b)=>num(b.tot)-num(a.tot)||num(b.sacks)-num(a.sacks)).slice(0,n)
  .map(r=>({id:r.id,name:r.name,team:r.team,dg:"def",pos:r.pos||r.grp||"",s:[["TKL",fm(r.tot)],["SACK",fm(r.sacks)],["INT",fm(r.ints)]]}))}
function stTab(v){
 const on=[...v.querySelectorAll(".dfx-tabs button.on")].map(x=>x.textContent.trim().toLowerCase());
 for(const t of on){if(t==="kickers")return"kickers";if(t==="punters")return"punters";if(t==="kick returns")return"kr";if(t==="punt returns")return"pr"}return"kickers"}
function topSt(tab,n){
 const c=STT[tab];
 return((DEFD&&DEFD[c.key])||[]).slice().sort((a,b)=>num(b[c.sort])-num(a[c.sort])).slice(0,n)
  .map(r=>({id:r.id,name:r.name,team:r.team,dg:{kickers:"k",punters:"p",kr:"kr",pr:"pr"}[tab],pos:r.pos||"",s:c.cols.map(x=>[x[0],fm(r[x[1]])])}))}

function cardHtml(it,i){
 const click=it.id!=null?` data-id="${E(it.id)}" data-pg="${E(it.dg||it.g||"")}" style="cursor:pointer"`:"";
 const img=it.id!=null?`<img alt="" decoding="async" fetchpriority="high" src="${E(IMG(it.id))}" data-f="${E(ESPN(it.id))}|${E(PORT(it.id))}" onerror="pc5Err(this)">`:"";
 return `<div class="pc5-card${it.bad?" pc5-bad":""}"${click}><div class="pc5-face">${img}</div><span class="pc5-rank">#${i+1}</span>
 <div class="pc5-info"><div class="pc5-n"><b>${E(it.name)}</b><span>${LG(it.team)}${E(it.team||"")}${it.pos?" &middot; "+E(it.pos):""}</span></div>
 <div class="pc5-s">${it.s.map(x=>`<span><i>${E(x[0])}</i>${E(x[1])}</span>`).join("")}</div></div></div>`}
function html(items,k,tab,n){
 const title=k==="st"?"Special Teams - "+STT[tab].t:TITLE[k];
 const basis=k==="st"?"by "+STT[tab].sort:BASIS[k];
 return `<div class="pc5-head"><b>Top ${items.length} - ${E(title)}</b><span>${E(basis)} | updates automatically</span></div><div class="pc5-row" style="--n:${n}">${items.map(cardHtml).join("")}</div>`}

function anchorFor(v,k){
 const h=v.querySelector("h1,h2,h3");if(!h)return null;
 let top=h;while(top.parentElement&&top.parentElement!==v)top=top.parentElement;
 const trd=k==="qb"||k==="receivers"||k==="rushing";
 if(trd){let p=top.previousElementSibling;while(p){if(p.id!=="pc5"){p.classList.add("trd-keep");if(p.style.display==="none")p.style.display=""}p=p.previousElementSibling}}
 let a=top,n=a.nextElementSibling,c=0;
 const isData=el=>el.matches("table,.tw,.trd-body,.trd-wrap,.dfx-card,.pkc")||!!el.querySelector("table");
 if(trd){
  while(n&&c<4){
   if(n.id==="pc5"){n=n.nextElementSibling;continue}
   if(n.classList.contains("trd-bar")){a=n;n=n.nextElementSibling;c++;continue}
   if(isData(n)||n.classList.contains("trd-body"))break;
   n.classList.add("trd-keep");if(n.style.display==="none")n.style.display="";a=n;n=n.nextElementSibling;c++}
 }else if(k==="def"||k==="st"){
  if(n&&n.id==="pc5")n=n.nextElementSibling;
  if(n&&n.classList.contains("dfx-tabs"))a=n}
 return a}

let warmed=false;
function run(){
 const v=document.getElementById("view");if(!v)return;
 if(!warmed&&typeof ALL!=="undefined"&&ALL&&ALL.qb&&ALL.qb.length){warmed=true;warmAll()}
 const old=v.querySelector("#pc5"),k=kind(v);
 if(!k){if(old)old.remove();return}
 if(typeof ALL==="undefined"||!ALL.qb)return;
 const n=colsFor(v);let items=null,tab="";
 if(k==="qb"||k==="receivers"||k==="rushing")items=topGroup(k,n);
 else if(k==="inj")items=topInj(n);
 else{loadDef();if(DEFD){if(k==="def")items=topDef(n);else{tab=stTab(v);items=topSt(tab,n)}}}
 if(!items)return;
 if(!items.length){if(old)old.remove();return}
 const a=anchorFor(v,k);if(!a)return;
 const sig=k+"|"+tab+"|"+n+"|"+JSON.stringify(items.map(i=>[i.id,i.name,i.s]));
 let el=old;
 if(!el||el.dataset.sig!==sig){
  const x=document.createElement("section");x.id="pc5";x.className="pc5 trd-keep";x.dataset.sig=sig;x.innerHTML=html(items,k,tab,n);
  if(el)el.replaceWith(x);el=x}
 if(el.previousElementSibling!==a)a.insertAdjacentElement("afterend",el)}

async function refresh(){
 if(document.hidden)return;
 try{const gs=["qb","receivers","rushing"],p=await Promise.all(gs.map(g=>fetch("/api/group/"+g).then(r=>r.json())));
  if(p.every(Array.isArray)){gs.forEach((g,i)=>{ALL[g]=p[i]});warmAll()}}catch(e){}
 DEFT=0;run()}

let t1=null,t2=null;const v0=document.getElementById("view");
if(v0)new MutationObserver(()=>{clearTimeout(t1);t1=setTimeout(()=>{try{run()}catch(e){console.log("pc5",e)}},120)}).observe(v0,{childList:true,subtree:true});
window.addEventListener("resize",()=>{clearTimeout(t2);t2=setTimeout(()=>{try{run()}catch(e){}},200)});
setInterval(()=>{try{run()}catch(e){}},3000);
setInterval(refresh,300000);
setTimeout(()=>{try{run()}catch(e){}},500);
})();
