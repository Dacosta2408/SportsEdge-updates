/* Sports Edge - NFL player pop-up 1.0
   Opens when you click a card in the Top players row on Quarterbacks, Receivers, Rushing, Injuries, Defense and Special Teams.
   Same look as the NBA pop-up: team-colour gradient, faded team logo, season tiles, last-games chart and game log.
   Only the top-row cards open it. Off switch: localStorage.pnf_off=1 */
(function(){
try{if(localStorage.getItem("pnf_off")==="1")return}catch(e){}
if(window.__pnf)return;window.__pnf=1;
const E=s=>String(s==null?"":s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const num=x=>{x=Number(x);return isFinite(x)?x:0};
const fm=x=>{if(x==null||x==="")return"-";x=Number(x);if(!isFinite(x))return"-";return Number.isInteger(x)?String(x):String(Math.round(x*10)/10)};
const IMG=id=>"https://a.espncdn.com/combiner/i?img=/i/headshots/nfl/players/full/"+id+".png&w=350&h=254";
const ESPN=id=>"https://a.espncdn.com/i/headshots/nfl/players/full/"+id+".png";
const COL={ARI:"97233F",ATL:"A71930",BAL:"3B2A9E",BUF:"00338D",CAR:"0085CA",CHI:"C83803",CIN:"FB4F14",CLE:"FF3C00",DAL:"003594",DEN:"FB4F14",DET:"0076B6",GB:"2F6B4F",HOU:"A71930",IND:"002C5F",JAX:"006778",JAC:"006778",KC:"E31837",LV:"8A8D8F",LAC:"0080C6",LAR:"003594",MIA:"008E97",MIN:"4F2683",NE:"C60C30",NO:"B8A36B",NYG:"0B2265",NYJ:"125740",PHI:"004C54",PIT:"FFB612",SF:"AA0000",SEA:"3E8E1E",TB:"D50A0A",TEN:"4B92DB",WSH:"773141",WAS:"773141"};
const GRP={
 qb:{name:"Quarterback",main:"passingYards",label:"YDS",cols:[["passingAttempts","ATT"],["completions","CMP"],["passingYards","YDS"],["passingTouchdowns","TD"],["interceptions","INT"]]},
 receivers:{name:"Receiver",main:"receivingYards",label:"YDS",cols:[["receivingTargets","TGT"],["receptions","REC"],["receivingYards","YDS"],["receivingTouchdowns","TD"]]},
 rushing:{name:"Rushing",main:"rushingYards",label:"YDS",cols:[["rushingAttempts","ATT"],["rushingYards","YDS"],["rushingTouchdowns","TD"]]}};
const SPEC={
 def:{list:"defense",name:"Defense",main:"tot",label:"TKL",tiles:[["TKL","tot"],["SACKS","sacks"],["TFL","tfl"],["PASS DEF","pd"],["INT","ints"],["QB HITS","qbh"],["GAMES","gp"],["TKL / G","tpg"]]},
 k:{list:"kickers",name:"Kicker",main:"kpts",label:"PTS",tiles:[["POINTS","pts"],["FG MADE","fgm"],["FG ATT","fga"],["FG %","fgpct"],["LONG","long"],["XP MADE","xpm"],["XP ATT","xpa"],["GAMES","gp"]]},
 p:{list:"punters",name:"Punter",main:"pyds",label:"YDS",tiles:[["PUNTS","no"],["YARDS","yds"],["AVG","avg"],["INSIDE 20","in20"],["TOUCHBACKS","tb"],["LONG","long"],["GAMES","gp"]]},
 kr:{list:"kick_returners",name:"Kick returner",main:"kryds",label:"YDS",tiles:[["RETURNS","no"],["YARDS","yds"],["AVG","avg"],["LONG","long"],["TD","td"],["GAMES","gp"]]},
 pr:{list:"punt_returners",name:"Punt returner",main:"pryds",label:"YDS",tiles:[["RETURNS","no"],["YARDS","yds"],["AVG","avg"],["LONG","long"],["TD","td"],["GAMES","gp"]]}};
const SH={tot:"TKL",sacks:"SACK",tfl:"TFL",pd:"PD",ints:"INT",qbh:"QBH",kpts:"PTS",fgm:"FGM",xpm:"XPM",pn:"PUNTS",pyds:"YDS",pin20:"IN20",kryds:"YDS",krn:"RET",pryds:"YDS",prn:"RET"};

const st=document.createElement("style");st.id="pnf-css";
st.textContent=`#pnf-ov{position:fixed;inset:0;z-index:99999;background:rgba(2,10,22,.78);display:flex;align-items:center;justify-content:center;padding:16px}
#pnf-box{position:relative;isolation:isolate;width:min(760px,100%);max-height:92vh;overflow:auto;border-radius:16px;color:#e8fbff;background:var(--pnf-bg,linear-gradient(160deg,#0b2a45,#061a2e));border:1px solid rgba(0,200,255,.45);box-shadow:0 20px 60px rgba(0,0,0,.6),0 0 30px rgba(0,190,255,.25);padding:18px 20px}
#pnf-box>*{position:relative;z-index:1}
#pnf-wm{position:absolute!important;z-index:0!important;right:-40px;top:-30px;width:360px;height:360px;object-fit:contain;opacity:.13;pointer-events:none;-webkit-mask-image:linear-gradient(200deg,#000 25%,transparent 80%);mask-image:linear-gradient(200deg,#000 25%,transparent 80%)}
#pnf-x{position:absolute;right:12px;top:12px;width:34px;height:34px;padding:0;border-radius:50%;border:1px solid rgba(124,236,255,.55);background:rgba(2,16,32,.75);color:#e8fbff;cursor:pointer;display:flex;align-items:center;justify-content:center;z-index:5}#pnf-x:hover{background:rgba(124,236,255,.25)}#pnf-x svg{display:block}
.pnf-top{display:flex;gap:16px;align-items:flex-end;margin-bottom:12px;padding-right:40px}
.pnf-ph{width:150px;height:110px;flex:none;border-radius:12px;background:rgba(0,190,255,.08);border:1px solid rgba(124,236,255,.3);overflow:hidden;position:relative}
.pnf-ph img{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;object-position:50% 15%}
.pnf-nm{font-size:22px;font-weight:900;color:#fff;line-height:1.1}
.pnf-sub{display:flex;gap:8px;align-items:center;flex-wrap:wrap;color:#8fdcf0;font-size:13px;margin-top:6px}
.pnf-sub img{width:20px;height:20px;object-fit:contain}
.pnf-pill{padding:2px 9px;border-radius:999px;font-size:11px;font-weight:800;background:rgba(22,163,74,.25);color:#4ade80}.pnf-pill.o{background:rgba(220,38,38,.25);color:#fca5a5}.pnf-pill.q{background:rgba(245,158,11,.25);color:#fcd34d}
.pnf-h{margin:18px 0 8px;font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:#7cecff;font-weight:800;display:flex;align-items:center;gap:8px}.pnf-h:before{content:"";width:4px;height:14px;border-radius:2px;background:#7cecff}.pnf-h.big{font-size:15px;letter-spacing:.06em;color:#fff;margin-top:20px}
.pnf-g{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px}
.pnf-t{background:rgba(0,190,255,.08);border:1px solid rgba(124,236,255,.22);border-radius:10px;padding:8px 10px;text-align:center}
.pnf-t b{display:block;font-size:20px;color:#fff}.pnf-t span{font-size:10px;color:#7aa6b8;letter-spacing:.06em}
.pnf-t.hi{border-color:#7cecff;background:rgba(0,190,255,.18)}
.pnf-bars{display:flex;align-items:flex-end;gap:6px;height:120px;padding:6px 4px 0}
.pnf-bars div{flex:1;display:flex;flex-direction:column;justify-content:flex-end;align-items:center;height:100%;font-size:10px;color:#cfefff}
.pnf-bars div i{display:block;width:100%;max-width:34px;border-radius:4px 4px 0 0;margin-top:2px}
.pnf-bars small{font-size:8.5px;color:#7aa6b8;margin-top:3px;white-space:nowrap}
.pnf-lw{border:1px solid rgba(124,236,255,.3);border-radius:12px;overflow:hidden;background:rgba(2,16,32,.55)}
#pnf-box .pnf-tb{width:100%;border-collapse:collapse;font-size:13px;background:transparent!important}
#pnf-box .pnf-tb th{text-align:center;color:#9fe6f7!important;background:rgba(0,190,255,.16)!important;font-size:11px;letter-spacing:.05em;text-transform:uppercase;padding:8px;font-weight:800;position:static}
#pnf-box .pnf-tb td{text-align:center;padding:7px 8px;color:#e8fbff!important;background:transparent!important;border-top:1px solid rgba(124,236,255,.14);font-weight:600;white-space:nowrap}
#pnf-box .pnf-tb tr:nth-child(even) td{background:rgba(124,236,255,.06)!important}
#pnf-box .pnf-tb th:first-child,#pnf-box .pnf-tb td:first-child,#pnf-box .pnf-tb th:nth-child(2),#pnf-box .pnf-tb td:nth-child(2){text-align:left}
#pnf-box .pnf-tb td.f{color:#7cecff!important;font-weight:900}#pnf-box .pnf-tb td.w{color:#4ade80!important}#pnf-box .pnf-tb td.l{color:#f87171!important}
@media(max-width:620px){.pnf-g{grid-template-columns:repeat(3,minmax(0,1fr))}.pnf-top{flex-direction:column;align-items:flex-start}}`;
document.head.appendChild(st);

const jj=async u=>{const r=await fetch(u);if(!r.ok)throw new Error("HTTP "+r.status);return r.json()};
const tm=ab=>{try{return(typeof TEAMS!=="undefined"&&TEAMS[ab])||null}catch(e){return null}};
const logo=ab=>{const t=tm(ab);return t&&t.logo?`<img alt="" src="${E(t.logo)}" onerror="this.style.visibility='hidden'">`:""};
window.pnfErr=function(im){const l=(im.dataset.f||"").split("|").filter(Boolean),i=+(im.dataset.i||0);if(i<l.length){im.dataset.i=String(i+1);im.src=l[i]}else im.style.visibility="hidden"};
function close(){const o=document.getElementById("pnf-ov");if(o)o.remove();document.removeEventListener("keydown",esc)}
function esc(e){if(e.key==="Escape")close()}
const trendTxt=t=>t>=.1?`<span style="color:#4ade80">&#9650; ${Math.round(t*100)}%</span>`:(t<=-.1?`<span style="color:#f87171">&#9660; ${Math.round(-t*100)}%</span>`:"flat");
function bars(vals,labels,avg){
 if(!vals.length)return '<p style="color:#7aa6b8">No game log yet.</p>';
 const mx=Math.max(1,...vals,avg);
 return `<div class="pnf-bars">${vals.map((v,i)=>`<div><span>${fm(v)}</span><i style="height:${Math.max(4,v/mx*80)}%;background:${v>=avg?"#22c55e":"#ef4444"}"></i><small>${E(labels[i])}</small></div>`).join("")}</div>`}
function table(head,rows){
 return `<div class="pnf-lw"><table class="pnf-tb"><tr>${head.map(h=>`<th>${E(h)}</th>`).join("")}</tr>${rows.join("")}</table></div>`}
const rc=r=>/^w/i.test(r||"")?"w":/^l/i.test(r||"")?"l":"";

async function open(id,pg){
 close();
 const ov=document.createElement("div");ov.id="pnf-ov";
 ov.innerHTML=`<div id="pnf-box" role="dialog" aria-modal="true"><button id="pnf-x" aria-label="Close"><svg width="14" height="14" viewBox="0 0 14 14" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M2 2l10 10M12 2L2 12"/></svg></button><div id="pnf-body">Loading player...</div></div>`;
 ov.addEventListener("click",e=>{if(e.target===ov)close()});ov.querySelector("#pnf-x").onclick=close;
 document.body.appendChild(ov);document.addEventListener("keydown",esc);
 let h;try{h=GRP[pg]?await fromLogs(id,pg):await fromDefense(id,pg)}catch(e){h=null}
 const body=document.getElementById("pnf-body");if(!body)return;
 if(!h){body.innerHTML='<p>No stats for this player yet.</p>';return}
 const box=document.getElementById("pnf-box");
 const c="#"+(COL[h.team]||"1b5fd1");
 box.style.setProperty("--pnf-bg","linear-gradient(145deg,"+c+"cc 0%,#0a2540 42%,#040f1d 100%)");
 const t=tm(h.team);if(t&&t.logo){const im=document.createElement("img");im.id="pnf-wm";im.alt="";im.src=t.logo;box.prepend(im)}
 body.innerHTML=h.html}
function head(p,badge,note,extra){
 const img=`<img alt="" src="${E(IMG(p.id))}" data-f="${E(ESPN(p.id))}|${E("/api/edge_auto/portrait/nfl_player_"+p.id+".png")}" data-i="0" onerror="pnfErr(this)">`;
 return `<div class="pnf-top"><div class="pnf-ph">${img}</div><div><div class="pnf-nm">${E(p.name)}</div>
 <div class="pnf-sub">${logo(p.team)}<span>${E(p.team||"")}</span><span>${E(p.pos||"")}</span>${badge}${extra||""}</div>
 ${note?`<div style="margin-top:6px;font-size:12px;color:#cfefff">${E(note)}</div>`:""}</div></div>`}
function pill(status){const s=status||"Healthy";const o=/out|reserve|\bir\b|susp/i.test(s),q=/doubt|quest|day/i.test(s);return `<span class="pnf-pill ${o?"o":q?"q":""}">${E(s)}</span>`}

async function fromLogs(id,pg){
 const cfg=GRP[pg],d=await jj("/api/player/"+encodeURIComponent(id));
 if(!d||!d.player)return null;
 const p=d.player,L=(d.logs||[]).filter(r=>r.played==null||num(r.played)!==0);
 let row=null;try{row=((typeof ALL!=="undefined"&&ALL[pg])||[]).find(r=>String(r.id)===String(id))}catch(e){}
 const k=cfg.main,vals=L.map(r=>num(r[k])),avg=vals.length?vals.reduce((a,b)=>a+b,0)/vals.length:0;
 const l3=vals.slice(-3),last3=l3.length?l3.reduce((a,b)=>a+b,0)/l3.length:0;
 const sum=key=>L.reduce((a,r)=>a+num(r[key]),0);
 const tiles=[[fm(avg),"AVG "+cfg.label+" / G",1],[fm(last3),"LAST 3",0],[row?Math.round(num(row.hit)*100)+"%":"-","HIT RATE",0],[row?fm(row.score):"-","HITSCORE",0],
  [fm(L.length),"GAMES",0],[row?E(row.next||"-"):"-","NEXT OPP",0],[fm(Math.max(0,...vals)),"SEASON HIGH",0],[trendTxt(avg>0?last3/avg-1:0),"TREND",0]];
 const totals=cfg.cols.map(c=>[fm(sum(c[0])),c[1]+" (SEASON)"]);
 const lab=L.slice(-10).map(r=>(r.ha||"")+" "+(r.opp||"")),v10=vals.slice(-10);
 const rows=L.slice().reverse().slice(0,10).map(r=>`<tr><td>${E(r.week)}</td><td>${E((r.ha||"")+" "+(r.opp||""))}</td><td class="${rc(r.result)}">${E(r.result||"-")}</td>${cfg.cols.map(c=>`<td${c[0]===k?' class="f"':""}>${fm(r[c[0]])}</td>`).join("")}</tr>`);
 const inj=d.injury||{};
 return {team:p.team,html:head({id:p.id,name:p.name,team:p.team,pos:p.pos},pill(inj.status),inj.note||"",`<span>${cfg.name}</span>`)
  +`<div class="pnf-h">Season averages</div><div class="pnf-g">${tiles.map(t=>`<div class="pnf-t${t[2]?" hi":""}"><b>${t[0]}</b><span>${t[1]}</span></div>`).join("")}</div>`
  +`<div class="pnf-h">Season totals</div><div class="pnf-g">${totals.map(t=>`<div class="pnf-t"><b>${t[0]}</b><span>${t[1]}</span></div>`).join("")}</div>`
  +`<div class="pnf-h">${cfg.label} - last ${v10.length} games <span style="color:#7aa6b8;text-transform:none;letter-spacing:0">(green = reached his ${fm(avg)} average)</span></div>${bars(v10,lab,avg)}`
  +(rows.length?`<div class="pnf-h big">Game log <span style="color:#7aa6b8;font-weight:600;letter-spacing:0;text-transform:none;font-size:12px">last ${rows.length} games</span></div>${table(["Wk","Opp","Result"].concat(cfg.cols.map(c=>c[1])),rows)}`:"")}}

let LG=null,LGT=0;
async function league(){if(LG&&Date.now()-LGT<120000)return LG;LG=await jj("/api/defense/players");LGT=Date.now();return LG}
async function fromDefense(id,pg){
 const sp=SPEC[pg];if(!sp)return null;
 const [lg,wk]=await Promise.all([league(),jj("/api/defense/weekly?group="+pg).catch(()=>null)]);
 const r=((lg&&lg[sp.list])||[]).find(x=>String(x.id)===String(id));if(!r)return null;
 const w=wk&&(wk.players||[]).find(x=>String(x.id)===String(id));
 const W=(w&&w.weeks)||[],vals=W.map(x=>num((x.v||{})[sp.main])),avg=vals.length?vals.reduce((a,b)=>a+b,0)/vals.length:0;
 const keys=(wk&&wk.stats?wk.stats:[]).map(s=>s[0]);
 const tiles=sp.tiles.map((t,i)=>[fm(r[t[1]]),t[0],i===0]);
 const lab=W.slice(-10).map(x=>(x.ha||"")+" "+(x.opp||"")),v10=vals.slice(-10);
 const rows=W.slice().reverse().slice(0,10).map(x=>`<tr><td>${E(x.week)}</td><td>${E((x.ha||"")+" "+(x.opp||""))}</td>${keys.map(k=>`<td${k===sp.main?' class="f"':""}>${fm((x.v||{})[k])}</td>`).join("")}</tr>`);
 return {team:r.team,html:head({id:r.id,name:r.name,team:r.team,pos:r.pos||r.grp},'<span class="pnf-pill">Active</span>',"",`<span>${sp.name}</span>${w&&w.next?`<span>Next: ${E(w.next)}</span>`:""}`)
  +`<div class="pnf-h">Season totals</div><div class="pnf-g">${tiles.map(t=>`<div class="pnf-t${t[2]?" hi":""}"><b>${t[0]}</b><span>${t[1]}</span></div>`).join("")}</div>`
  +`<div class="pnf-h">${sp.label} - last ${v10.length} games <span style="color:#7aa6b8;text-transform:none;letter-spacing:0">(green = reached his ${fm(avg)} average)</span></div>${bars(v10,lab,avg)}`
  +(rows.length?`<div class="pnf-h big">Game log <span style="color:#7aa6b8;font-weight:600;letter-spacing:0;text-transform:none;font-size:12px">last ${rows.length} games</span></div>${table(["Wk","Opp"].concat(keys.map(k=>SH[k]||k)),rows)}`:"")}}

/* only the cards in the Top players row open this pop-up */
document.addEventListener("click",e=>{
 const c=e.target.closest&&e.target.closest("#pc5 .pc5-card");if(!c||!c.dataset.id||!c.dataset.pg)return;
 e.preventDefault();e.stopPropagation();open(c.dataset.id,c.dataset.pg)},true);
})();
