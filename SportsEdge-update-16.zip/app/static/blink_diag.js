/* Sports Edge - blink diagnostic v1.0 (temporary, read-only: it only records, it changes nothing on screen except a small D button) */
(function(){
if(window.__seDiag)return;window.__seDiag=1;
var KEY="se_diag_log",MAX=250,T0=Date.now();
function load(){try{return JSON.parse(localStorage.getItem(KEY)||"[]")}catch(e){return[]}}
var log=load();
function save(){try{localStorage.setItem(KEY,JSON.stringify(log.slice(-MAX)))}catch(e){}}
function fmt(t){var d=new Date(t);return d.toTimeString().slice(0,8)}
function page(){try{return typeof page!=="undefined"?page:""}catch(e){return""}}
function add(kind,msg){
  var p="";try{p=(window.page||"")+""}catch(e){}
  log.push({t:Date.now(),k:kind,m:msg,p:p||location.hash||""});
  if(log.length>MAX)log=log.slice(-MAX);save();paint()}
function who(){
  try{var s=(new Error()).stack||"",re=/static\/([\w.\-]+\.js)(?:\?[^:\s)]*)?:(\d+)/g,m;
    while((m=re.exec(s))){if(m[1]!=="blink_diag.js")return m[1]+":"+m[2]}
  }catch(e){}return"unknown"}
function desc(el){if(!el)return"?";var s=(el.tagName||"").toLowerCase();if(el.id)s+="#"+el.id;else if(el.className&&typeof el.className==="string")s+="."+el.className.trim().split(/\s+/)[0];return s}
/* 1. who rewrites big chunks of the page */
var last={};
function note(el,what,n){
  if(n<4)return;
  var key=desc(el)+what+who(),now=Date.now();
  if(last[key]&&now-last[key]<2000)return;last[key]=now;
  add("redraw",desc(el)+" rewritten by "+who()+" ("+n+" items) via "+what)}
try{
  var d=Object.getOwnPropertyDescriptor(Element.prototype,"innerHTML");
  Object.defineProperty(Element.prototype,"innerHTML",{get:d.get,configurable:true,set:function(v){
    try{note(this,"innerHTML",this.childElementCount)}catch(e){}return d.set.call(this,v)}});
  var rc=Element.prototype.replaceChildren;
  Element.prototype.replaceChildren=function(){try{note(this,"replaceChildren",this.childElementCount)}catch(e){}return rc.apply(this,arguments)};
}catch(e){}
/* 2. slow moments (the screen freezes for a moment) */
try{new PerformanceObserver(function(l){l.getEntries().forEach(function(e){if(e.duration>=80)add("freeze","page froze for "+Math.round(e.duration)+" ms")})}).observe({entryTypes:["longtask"]})}catch(e){}
/* 3. whole page reloads */
window.addEventListener("beforeunload",function(){add("reload","whole page reloaded by "+who())});
var oRel=null;try{if(location.reload&&false)oRel=1}catch(e){}
/* 4. slow or failing data calls */
try{var of=window.fetch;window.fetch=function(u){var t=Date.now(),us=(typeof u==="string"?u:(u&&u.url)||"")+"";
  return of.apply(this,arguments).then(function(r){var ms=Date.now()-t;if(ms>2500)add("slow-data",us.slice(0,70)+" took "+ms+" ms");if(!r.ok&&r.status>=500)add("data-error",us.slice(0,70)+" status "+r.status);return r},function(e){add("data-error",us.slice(0,70)+" failed");throw e})}}catch(e){}
/* 5. errors */
window.addEventListener("error",function(e){add("error",(e.message||"error")+" "+((e.filename||"").split("/").pop()||"")+":"+(e.lineno||""))});
/* 6. big visible shifts: main area emptied */
try{var v=document.getElementById("view");if(v){var wasFull=false;new MutationObserver(function(){
  var full=v.childElementCount>0&&v.offsetHeight>200;
  if(wasFull&&!full)add("blank","main area went empty for a moment, caused near "+who());wasFull=full}).observe(v,{childList:true,subtree:false});}}catch(e){}
/* button and panel */
var b,pn,pre;
function ui(){
  if(b||!document.body)return;
  b=document.createElement("div");b.textContent="D";b.title="Blink diagnostic";
  b.style.cssText="position:fixed;left:6px;bottom:6px;z-index:2147483647;width:22px;height:22px;border-radius:11px;background:#1f2937;color:#9ca3af;font:700 11px/22px sans-serif;text-align:center;cursor:pointer;opacity:.55";
  pn=document.createElement("div");pn.style.cssText="display:none;position:fixed;left:6px;bottom:34px;z-index:2147483647;width:min(560px,92vw);max-height:60vh;background:#0b1220;color:#d1d5db;border:1px solid #374151;border-radius:8px;padding:8px;font:12px/1.4 monospace";
  var bar=document.createElement("div");bar.style.cssText="margin-bottom:6px;display:flex;gap:6px";
  function btn(t,f){var x=document.createElement("button");x.textContent=t;x.style.cssText="background:#1f2937;color:#e5e7eb;border:1px solid #374151;border-radius:6px;padding:3px 10px;cursor:pointer";x.onclick=f;bar.appendChild(x)}
  btn("Copy",function(){var t=text();try{navigator.clipboard.writeText(t)}catch(e){var a=document.createElement("textarea");a.value=t;document.body.appendChild(a);a.select();document.execCommand("copy");a.remove()}});
  btn("Clear",function(){log=[];save();paint()});
  btn("Close",function(){pn.style.display="none"});
  pre=document.createElement("div");pre.style.cssText="overflow:auto;max-height:calc(60vh - 46px);white-space:pre-wrap";
  pn.appendChild(bar);pn.appendChild(pre);
  b.onclick=function(){pn.style.display=pn.style.display==="none"?"block":"none";paint()};
  document.body.appendChild(b);document.body.appendChild(pn);paint()}
function text(){return "Blink diagnostic - "+log.length+" events\n"+log.map(function(e){return fmt(e.t)+"  ["+e.k+"]  page:"+e.p+"  "+e.m}).join("\n")}
function paint(){if(pre&&pn.style.display!=="none")pre.textContent=text().split("\n").reverse().join("\n")}
(function w(){if(document.body)ui();else setTimeout(w,200)})();
add("start","diagnostic running");
})();
