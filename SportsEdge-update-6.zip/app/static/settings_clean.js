/* Sports Edge - Settings clean-up 1.1: tabs for the Settings cards + scroll guard. Off switch: localStorage.scl_off=1 */
(function(){
try{if(localStorage.getItem("scl_off")==="1")return}catch(e){}
if(window.__scl)return;window.__scl=1;
const KEY="scl_tab";
const TABS=[["data","Data & Backups"],["updates","Updates"],["alerts","Alerts"],["setup","Keys & Betting"],["about","About"]];
const RULES=[["alerts",/alert|notification/i],["data",/data health|backup|database|sports data|saved/i],["updates",/update|automatic|roster|contract|nhl/i],["setup",/odds|api|key|gemini|assistant|bankroll|staking|model|last season/i],["about",/about|phone|qr|version/i]];
const grp=t=>{for(const r of RULES)if(r[1].test(t))return r[0];return "about"};
let cur="data";try{cur=localStorage.getItem(KEY)||"data"}catch(e){}

const st=document.createElement("style");st.id="scl-css";
st.textContent=`#scl-bar{display:flex;gap:8px;flex-wrap:wrap;margin:10px 0 16px}
#scl-bar button{padding:8px 18px;border-radius:999px;border:1px solid var(--line);background:var(--card);color:var(--ink);font-weight:700;font-size:13px;cursor:pointer}
#scl-bar button:hover{border-color:#2563eb}
#scl-bar button.on{background:#2563eb;border-color:#2563eb;color:#fff}
#view[data-scl-on] #hl-card .hl-row .hl-b.go{display:none}
#view[data-scl-on] #hl-card+#mnt-card{margin-top:-6px}`;
document.head.appendChild(st);
const dyn=document.createElement("style");dyn.id="scl-dyn";document.head.appendChild(dyn);

const isSet=()=>{try{return /(^|:)settings$/.test(String(page))}catch(e){return false}};
function tag(v){
 [...v.children].forEach(el=>{
  if(/^(H1|H2|P|STYLE|SCRIPT)$/.test(el.tagName)||el.id==="scl-bar")return;
  const kids=el.classList.contains("two")?[...el.children]:[el];
  kids.forEach(k=>{const h=k.querySelector("h3,h4,h2"),t=((h?h.textContent:k.textContent)||"").trim().slice(0,80);const g=grp(t);if(k.dataset.scl!==g)k.dataset.scl=g})})}
let lastCss="";
function show(){
 const css=`#view[data-scl-on] [data-scl]:not([data-scl="${cur}"]){display:none!important}#view[data-scl-on] .two:not(:has([data-scl="${cur}"])){display:none!important}`;
 if(css!==lastCss){lastCss=css;dyn.textContent=css}}
function mark(v){
 const b=v.querySelector("#scl-bar");if(!b)return;
 const has=k=>v.querySelector('[data-scl="'+k+'"]')!==null;
 if(!has(cur)){const f=TABS.find(t=>has(t[0]));if(f)cur=f[0]}
 b.querySelectorAll("button").forEach(x=>{const d=has(x.dataset.k)?"":"none";if(x.style.display!==d)x.style.display=d;const on=x.dataset.k===cur;if(x.classList.contains("on")!==on)x.classList.toggle("on",on)})}
function run(){
 if(!isSet())return;const v=document.getElementById("view");if(!v||!v.querySelector("h2"))return;
 if(!v.querySelector("#scl-bar")){
  const b=document.createElement("div");b.id="scl-bar";
  b.innerHTML=TABS.map(t=>`<button data-k="${t[0]}">${t[1]}</button>`).join("");
  b.onclick=e=>{const k=e.target.dataset&&e.target.dataset.k;if(!k)return;cur=k;try{localStorage.setItem(KEY,k)}catch(x){}mark(v);show()};
  v.querySelector("h2").insertAdjacentElement("afterend",b)}
 tag(v);if(!v.hasAttribute("data-scl-on"))v.setAttribute("data-scl-on","1");mark(v);show()}
let t1=null;const v0=document.getElementById("view");
if(v0)new MutationObserver(()=>{clearTimeout(t1);t1=setTimeout(()=>{try{run()}catch(e){console.log("scl",e)}},250)}).observe(v0,{childList:true,subtree:true});
setInterval(()=>{try{run()}catch(e){}},2000);

/* scroll guard: if a click on Settings makes the page jump back to the top, put it back */
(function(){
 const main=()=>document.querySelector("main"),view=()=>document.getElementById("view");
 let snap=null,until=0;
 const take=()=>({w:window.scrollY||0,m:main()?main().scrollTop:0,v:view()?view().scrollTop:0});
 document.addEventListener("pointerdown",e=>{
  if(!isSet()){until=0;return}
  const v=view();
  if(v&&v.contains(e.target)){snap=take();until=Date.now()+8000}else until=0},true);
 ["wheel","touchmove","keydown"].forEach(t=>document.addEventListener(t,()=>{until=0},{capture:true,passive:true}));
 function fix(){
  if(!snap||Date.now()>until||!isSet())return;
  const c=take();
  if(snap.w>80&&c.w<snap.w-80)window.scrollTo(0,snap.w);
  const m=main();if(m&&snap.m>80&&c.m<snap.m-80)m.scrollTop=snap.m;
  const v=view();if(v&&snap.v>80&&c.v<snap.v-80)v.scrollTop=snap.v}
 document.addEventListener("scroll",()=>requestAnimationFrame(fix),true);
 setInterval(fix,200);
})();
})();
