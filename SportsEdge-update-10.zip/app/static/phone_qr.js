/* Phone View QR 1.0: adds a "QR codes" card to the Phone View section of Settings, with a code for home Wi-Fi and a code for Tailscale (works anywhere).
   Also opens the full page at /phone. Reads /api/phoneinfo and /api/phoneqr. Console helper: PhoneQR.debug() */
(function(){
if(window.PhoneQR&&window.PhoneQR.v==="1.0")return;
const E=s=>String(s==null?"":s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
const css=document.createElement("style");css.textContent=`#pqr{margin:14px 0;padding:14px 16px;border:1px solid var(--line,#d8dce5);border-radius:14px;background:var(--card,#fff);color:var(--ink,inherit)}#pqr h3{margin:0 0 4px;font-size:16px}#pqr small{color:var(--mut,#667)}
#pqr .g{display:grid;grid-template-columns:repeat(auto-fit,minmax(230px,1fr));gap:14px;margin-top:10px}#pqr .c{text-align:center;padding:10px;border:1px solid var(--line,#d8dce5);border-radius:12px}#pqr .c img{width:190px;max-width:100%;border-radius:8px;background:#fff}#pqr .u{font-family:Consolas,monospace;font-size:12.5px;word-break:break-all;margin-top:6px}
#pqr a{font-weight:700}`;document.head.appendChild(css);
const txt=el=>(el.innerText||el.textContent||"").trim();
let last=0,html="";
async function build(){const d=await (await fetch("/api/phoneinfo",{cache:"no-store"})).json();
 const card=(t,sub,u)=>`<div class="c"><b>${t}</b><br><small>${sub}</small>${u&&d.qr_ready?`<br><img alt="QR code" src="/api/phoneqr?data=${encodeURIComponent(u)}">`:""}<div class="u">${u?E(u):"Not set up yet"}</div></div>`;
 return `<h3>Scan with your phone camera</h3><small>${d.on?"Phone View is on.":"Switch Phone View on first."} ${d.qr_ready?"":"QR images need: python -m pip install segno (then restart). "}<a href="/phone" target="_blank" rel="noopener">Open full QR page</a></small><div class="g">${card("At home","Same Wi-Fi as this PC",d.lan)}${card("Anywhere","Tailscale on this PC and the phone",d.tailscale)}</div>`}
function anchor(){const v=document.getElementById("view");if(!v)return null;
 const els=[...v.querySelectorAll("h1,h2,h3,h4,b,strong,div,span,label")].filter(e=>e.children.length<=3&&/^phone view\b/i.test(txt(e).split("\n")[0])&&txt(e).length<400);
 return els.sort((a,b)=>txt(a).length-txt(b).length)[0]||null}
let busy=false;
async function tick(){if(busy)return;busy=true;try{const all=document.querySelectorAll("#pqr");for(let i=1;i<all.length;i++)all[i].remove();const a=anchor();const have=document.getElementById("pqr");
 if(!a){if(have)have.remove();return}
 if(have&&have.previousElementSibling&&Date.now()-last<20000)return;
 let blk=a;while(blk.parentElement&&blk.parentElement.id!=="view"&&txt(blk.parentElement).length<600&&!blk.parentElement.classList.contains("sv2"))blk=blk.parentElement;
 const h=await build();last=Date.now();let box=have;if(!box){box=document.createElement("div");box.id="pqr";box.dataset.r310="phone"}
 if(h!==html||!have){box.innerHTML=h;html=h}
 if(box.previousElementSibling!==blk)blk.after(box)}catch(e){}finally{busy=false}}
setInterval(tick,1500);
window.PhoneQR={v:"1.0",tick,debug(){const a=anchor();return{anchorFound:!!a,anchorText:a?txt(a).slice(0,60):null,card:!!document.getElementById("pqr")}}};
})();
