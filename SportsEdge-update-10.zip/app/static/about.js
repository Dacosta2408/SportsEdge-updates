
/* Settings > About: credits, and how to put the app on a phone's home screen. */
(function(){try{
 if(typeof pgSettings!=="function")return;
 const _ps=pgSettings;
 pgSettings=async function(){await _ps();if(page!=="settings")return;
  const v=document.getElementById("view");
  const credits=`<div class="credits"><div class="crd"><span class="av">DA</span><div><b>David Acosta</b><small>SPORTS EDGE - Developer and Founder</small><i>The vision behind every panel</i></div></div>
   <div class="crd"><span class="av ai">AU</span><div><b>Audible</b><small>IT and Lead Designer</small><i>The AI that calls the plays, built with Perplexity</i></div></div></div>`;
  const h=[...v.querySelectorAll(".pkh h3")].find(x=>x.textContent.trim()==="About"),card=h&&h.closest(".card"),sb=card&&card.querySelector(".sbody");
  if(sb&&!sb.querySelector(".credits"))sb.insertAdjacentHTML("afterbegin",credits);
  else if(!card&&!v.querySelector(".credits"))v.insertAdjacentHTML("beforeend",`<div class="card pkc"><div class="pkh"><h3>About</h3></div><div class="sbody">${credits}</div></div>`);
  const pc=document.getElementById("phonecard"),pb=pc&&pc.querySelector(".sbody");
  if(pb&&!pb.querySelector(".pwa"))pb.insertAdjacentHTML("beforeend",`<div class="pwa"><p><b>Put it on your phone like an app</b></p>
   <p class="mut"><b>iPhone:</b> open the address in Safari, tap Share, then Add to Home Screen, and leave Open as Web App on. It gets its own icon and opens full screen.<br><b>Android:</b> open the address in Chrome, tap the menu, then Add to Home screen.<br>This computer must be running Sports Edge, and the phone must be on the same Wi-Fi. The menu button at the top left opens the side panel on a small screen.</p></div>`)};
}catch(e){console.error("about",e)}})();

// overlay test
