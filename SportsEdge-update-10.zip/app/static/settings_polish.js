/* Sports Edge - Settings buttons 1.1: CSS only. Even, aligned section buttons. Off: localStorage.sp2_off=1 */
(function(){
try{if(localStorage.getItem("sp2_off")==="1")return}catch(e){}
if(document.getElementById("sp2-css"))return;
const st=document.createElement("style");st.id="sp2-css";
st.textContent=`
#view #r310-menu.r310-menu{position:sticky;top:0;z-index:20;display:grid;grid-template-columns:repeat(7,minmax(0,1fr));gap:8px;
 align-items:center;padding:12px 14px 14px;margin:8px 0 16px;background:var(--card,#fff);
 border:1px solid var(--line,#d8dce5);border-radius:14px;box-shadow:0 3px 10px rgba(15,23,42,.08)}
#view #r310-menu.r310-menu h2{grid-column:1/-1;margin:0 0 4px;font-size:20px}
#view #r310-menu.r310-menu a{display:flex;align-items:center;justify-content:center;box-sizing:border-box;width:100%;height:36px;
 padding:0 8px;border-radius:999px;border:1px solid var(--line,#c9cfdb)!important;background:var(--card,#fff);
 color:var(--ink,#111827)!important;font-size:13px;font-weight:700;line-height:1;white-space:nowrap;text-decoration:none;cursor:pointer}
#view #r310-menu.r310-menu a:hover{border-color:#2563eb!important;color:#2563eb!important}
@media(max-width:900px){#view #r310-menu.r310-menu{grid-template-columns:repeat(3,minmax(0,1fr))}}`;
document.head.appendChild(st);
})();
